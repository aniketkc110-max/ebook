import { FoodItem, Order, Student, DeviceLockInfo, OrderStatus } from '../types';
import { INITIAL_MENU } from '../data/menu';
import { INITIAL_STUDENTS } from '../data/students';
import jamunMojitoImage from '../assets/images/jamun_lemon_mojito_1787479058344.jpg';

const KEYS = {
  ORDERS: 'jusso_orders_v5',
  MENU: 'jusso_menu_v4',
  STUDENTS: 'flame_co_students_v3',
  DEVICE_ID: 'jusso_device_id_v2',
  DEVICE_ORDER: 'jusso_device_order_v5',
};

// Clear legacy keys and wipe all existing orders as requested
try {
  localStorage.setItem(KEYS.ORDERS, JSON.stringify([]));
  localStorage.removeItem(KEYS.DEVICE_ORDER);
  localStorage.removeItem('jusso_orders_v4');
  localStorage.removeItem('jusso_device_order_v4');
  localStorage.removeItem('jusso_orders_v3');
  localStorage.removeItem('flame_co_orders_v2');
  localStorage.removeItem('flame_co_device_order_v2');
} catch (e) {
  // Ignore
}

export function getOrCreateDeviceId(): string {
  try {
    let devId = localStorage.getItem(KEYS.DEVICE_ID);
    if (!devId) {
      devId = 'DEV-' + Math.random().toString(36).substring(2, 9).toUpperCase();
      localStorage.setItem(KEYS.DEVICE_ID, devId);
    }
    return devId;
  } catch (e) {
    return 'DEV-LOCAL-SESSION';
  }
}

export function getStudents(): Student[] {
  try {
    const raw = localStorage.getItem(KEYS.STUDENTS);
    if (raw) {
      return JSON.parse(raw);
    }
  } catch (e) {
    console.error('Error reading students', e);
  }
  localStorage.setItem(KEYS.STUDENTS, JSON.stringify(INITIAL_STUDENTS));
  return INITIAL_STUDENTS;
}

export function getMenuItems(): FoodItem[] {
  try {
    const raw = localStorage.getItem(KEYS.MENU);
    if (raw) {
      const parsed: FoodItem[] = JSON.parse(raw);
      const cleaned = parsed.map((item) => {
        let updated = item.category === 'Snacks & Fast Food'
          ? { ...item, category: 'Chaat & Street Food' as const }
          : item;
        if (updated.id === 'FOOD-101' || updated.name.toLowerCase().includes('sandwich')) {
          if (
            !updated.description ||
            updated.description.includes('Triple-decker') ||
            updated.description.includes('toasted sandwich')
          ) {
            updated = {
              ...updated,
              description:
                'Three layers of deliciousness, packed with flavor and served with a creamy mayo dip & crispy wafers! 🥪🔥',
            };
          }
        }
        if (updated.id === 'FOOD-102' || updated.name.toLowerCase().includes('pani puri')) {
          if (
            !updated.description ||
            updated.description.includes('Crispy hollow puris') ||
            updated.description.includes('chickpea filling')
          ) {
            updated = {
              ...updated,
              description:
                'Crispy puris, tasty masala & refreshing mint water! 🌿🥣',
            };
          }
        }
        if (updated.id === 'FOOD-103' || updated.name.toLowerCase().includes('chole')) {
          if (
            !updated.description ||
            updated.description.includes('Authentic Punjabi style') ||
            updated.description.includes('spicy chickpea curry')
          ) {
            updated = {
              ...updated,
              description:
                'Crispy kulcha, flavourful Amritsari chole & fresh onion salad—a perfect Punjabi feast! 🌶️🥙',
            };
          }
        }
        if (updated.id === 'FOOD-104' || updated.category === 'Beverages & Drinks' || updated.name.toLowerCase().includes('mojito') || updated.name.toLowerCase().includes('jamun')) {
          const needsDescUpdate =
            !updated.description ||
            updated.description.includes('Refreshing sparkling cooler') ||
            updated.description.includes('black plum');
          updated = {
            ...updated,
            description: needsDescUpdate
              ? 'Jamun, lemon & fizzy soda with a sweet-salty twist! 🍇🍋✨'
              : updated.description,
            image: jamunMojitoImage,
          };
        }
        if (updated.id === 'FOOD-105' || updated.category === 'Desserts' || updated.name.toLowerCase().includes('trifle') || updated.name.toLowerCase().includes('brownie')) {
          if (
            !updated.description ||
            updated.description.includes('Rich layered dessert') ||
            updated.description.includes('brownie crumble') ||
            updated.name === 'Brownie Trifle'
          ) {
            updated = {
              ...updated,
              name: 'Blueberry Trifle',
              image: 'https://images.unsplash.com/photo-1488477181946-6428a0291777?auto=format&fit=crop&w=600&q=80',
              description:
                'Crunchy biscuit, creamy vanilla cake & blueberry layers topped with juicy blueberries—a dreamy dessert in every spoonful! 🫐✨',
            };
          }
        }
        return updated;
      });
      return cleaned;
    }
  } catch (e) {
    console.error('Error reading menu', e);
  }
  localStorage.setItem(KEYS.MENU, JSON.stringify(INITIAL_MENU));
  return INITIAL_MENU;
}

export function saveMenuItems(items: FoodItem[]): void {
  try {
    localStorage.setItem(KEYS.MENU, JSON.stringify(items));
  } catch (e) {
    console.error('Error saving menu', e);
  }
}

export function getOrders(): Order[] {
  try {
    const raw = localStorage.getItem(KEYS.ORDERS);
    if (raw) {
      return JSON.parse(raw);
    }
  } catch (e) {
    console.error('Error reading orders', e);
  }
  return [];
}

export function saveOrder(order: Order): void {
  try {
    const existing = getOrders();
    const updated = [order, ...existing];
    localStorage.setItem(KEYS.ORDERS, JSON.stringify(updated));

    // Save device lock
    const lockInfo: DeviceLockInfo = {
      deviceId: order.deviceId,
      studentId: order.studentId,
      studentName: order.studentName,
      orderNumber: order.orderNumber,
      orderDate: order.createdAt,
    };
    localStorage.setItem(KEYS.DEVICE_ORDER, JSON.stringify(lockInfo));
  } catch (e) {
    console.error('Error saving order', e);
  }
}

export function updateOrderStatus(orderNumber: string, status: OrderStatus): void {
  try {
    const orders = getOrders();
    const updated = orders.map((o) => (o.orderNumber === orderNumber ? { ...o, status } : o));
    localStorage.setItem(KEYS.ORDERS, JSON.stringify(updated));
  } catch (e) {
    console.error('Error updating order status', e);
  }
}

export function deleteOrder(orderNumber: string): void {
  try {
    const orders = getOrders();
    const updated = orders.filter((o) => o.orderNumber !== orderNumber);
    localStorage.setItem(KEYS.ORDERS, JSON.stringify(updated));

    // If device lock matches deleted order, clear device lock
    const currentLock = getDeviceOrder();
    if (currentLock && currentLock.orderNumber === orderNumber) {
      localStorage.removeItem(KEYS.DEVICE_ORDER);
    }
  } catch (e) {
    console.error('Error deleting order', e);
  }
}

export function getDeviceOrder(): DeviceLockInfo | null {
  try {
    const raw = localStorage.getItem(KEYS.DEVICE_ORDER);
    if (raw) {
      const lock: DeviceLockInfo = JSON.parse(raw);
      // Double check if order exists in DB
      const orders = getOrders();
      const orderExists = orders.find((o) => o.orderNumber === lock.orderNumber || o.studentId === lock.studentId);
      if (orderExists) {
        return lock;
      }
    }
  } catch (e) {
    console.error('Error checking device order', e);
  }
  return null;
}

export function getStudentExistingOrder(studentId: string): Order | null {
  const orders = getOrders();
  return orders.find((o) => o.studentId === studentId) || null;
}

export function deleteCompletedOrders(): void {
  try {
    const orders = getOrders();
    const updated = orders.filter((o) => o.status !== 'Completed');
    localStorage.setItem(KEYS.ORDERS, JSON.stringify(updated));

    const currentLock = getDeviceOrder();
    if (currentLock) {
      const stillExists = updated.some((o) => o.orderNumber === currentLock.orderNumber);
      if (!stillExists) {
        localStorage.removeItem(KEYS.DEVICE_ORDER);
      }
    }
  } catch (e) {
    console.error('Error deleting completed orders', e);
  }
}

export function deleteAllOrders(): void {
  try {
    localStorage.setItem(KEYS.ORDERS, JSON.stringify([]));
    localStorage.removeItem(KEYS.DEVICE_ORDER);
    localStorage.removeItem('jusso_orders_v4');
    localStorage.removeItem('jusso_device_order_v4');
    localStorage.removeItem('jusso_orders_v3');
    localStorage.removeItem('flame_co_orders_v2');
    localStorage.removeItem('flame_co_device_order_v2');
  } catch (e) {
    console.error('Error deleting all orders', e);
  }
}

export function clearDeviceLock(): void {
  try {
    localStorage.removeItem(KEYS.DEVICE_ORDER);
  } catch (e) {
    console.error('Error clearing device lock', e);
  }
}

export function resetAllData(): void {
  try {
    localStorage.removeItem(KEYS.ORDERS);
    localStorage.removeItem(KEYS.DEVICE_ORDER);
    localStorage.setItem(KEYS.MENU, JSON.stringify(INITIAL_MENU));
    localStorage.setItem(KEYS.STUDENTS, JSON.stringify(INITIAL_STUDENTS));
  } catch (e) {
    console.error('Error resetting data', e);
  }
}
