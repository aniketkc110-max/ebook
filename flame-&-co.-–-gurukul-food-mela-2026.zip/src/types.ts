export type OrderStatus = 'Pending' | 'Preparing' | 'Ready' | 'Completed';

export interface Student {
  id: string; // e.g. STU-1001
  firstName: string; // e.g. Dhairya
  parentName: string; // e.g. Bhavesh
  fullName: string; // e.g. Dhairya Bhavesh Shah
  grade: string; // e.g. Grade 10-A
}

export interface FoodItem {
  id: string;
  name: string;
  category: string;
  description: string;
  price: number;
  image: string;
  isVeg: boolean;
  isChefSpecial?: boolean;
  isAvailable: boolean;
}

export interface CartItem {
  food: FoodItem;
  quantity: number;
}

export interface OrderItem {
  id: string;
  name: string;
  price: number;
  quantity: number;
  total: number;
}

export interface Order {
  orderNumber: string; // e.g. FLM-2026-8942
  studentId: string;
  studentName: string; // e.g. Dhairya (Bhavesh)
  parentName: string;
  fullName: string;
  deviceId: string;
  peopleCount: number; // 1 to 5
  allowedBudget: number; // peopleCount * 220
  items: OrderItem[];
  totalAmount: number;
  status: OrderStatus;
  createdAt: string; // ISO date string
  dateDisplay: string;
  timeDisplay: string;
}

export interface DeviceLockInfo {
  deviceId: string;
  studentId: string;
  studentName: string;
  orderNumber: string;
  orderDate: string;
}
