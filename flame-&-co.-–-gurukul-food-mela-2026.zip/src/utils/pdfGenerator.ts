import jsPDF from 'jspdf';
import { Order } from '../types';

export const generateAndDownloadPDFReceipt = (order: Order) => {
  const doc = new jsPDF();
  const cleanStudentName = order.studentName.replace(/\s*\(.*\)/, '').trim();

  // Header Banner
  doc.setFillColor(30, 16, 60); // Dark Purple
  doc.rect(0, 0, 210, 38, 'F');

  doc.setTextColor(255, 215, 0); // Gold
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(18);
  doc.text('FAMILY FIESTA', 105, 18, { align: 'center' });

  doc.setTextColor(220, 210, 255);
  doc.setFontSize(12);
  doc.text('OFFICIAL ORDER RECEIPT', 105, 28, { align: 'center' });

  // Order Summary Box
  doc.setDrawColor(180, 150, 240);
  doc.setLineWidth(0.5);
  doc.roundedRect(15, 45, 180, 32, 3, 3);

  doc.setTextColor(30, 16, 60);
  doc.setFontSize(11);
  doc.setFont('helvetica', 'bold');
  doc.text(`Order Token : #${order.orderNumber}`, 22, 55);
  doc.text(`Status : ${order.status}`, 140, 55);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(10);
  doc.setTextColor(50, 50, 50);
  doc.text(`Date & Time : ${order.dateDisplay || ''} ${order.timeDisplay}`, 22, 63);
  doc.text(`Group Size : ${order.peopleCount} Person(s)`, 140, 63);
  doc.text(`Budget Limit : Rs. ${order.allowedBudget}`, 22, 71);

  // Student & Parent Details
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(12);
  doc.setTextColor(30, 16, 60);
  doc.text('STUDENT & PARENT DETAILS', 15, 88);

  doc.setLineWidth(0.3);
  doc.setDrawColor(200, 200, 220);
  doc.line(15, 91, 195, 91);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(10);
  doc.setTextColor(40, 40, 40);
  doc.text(`Student Name : ${cleanStudentName}`, 20, 99);
  doc.text(`Student ID   : ${order.studentId}`, 120, 99);
  doc.text(`Parent Name  : ${order.parentName}`, 20, 107);
  doc.text(`Full Name    : ${order.fullName}`, 120, 107);

  // Ordered Items
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(12);
  doc.setTextColor(30, 16, 60);
  doc.text('ORDERED ITEMS', 15, 122);
  doc.line(15, 125, 195, 125);

  // Table Header
  doc.setFillColor(240, 235, 255);
  doc.rect(15, 129, 180, 8, 'F');
  doc.setFontSize(10);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(30, 16, 60);
  doc.text('Item Description', 20, 135);
  doc.text('Qty', 125, 135, { align: 'center' });
  doc.text('Price', 155, 135, { align: 'right' });
  doc.text('Total', 190, 135, { align: 'right' });

  let y = 143;
  order.items.forEach((item, index) => {
    if (index % 2 === 1) {
      doc.setFillColor(250, 250, 253);
      doc.rect(15, y - 5, 180, 8, 'F');
    }
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(40, 40, 40);
    doc.text(item.name, 20, y);
    doc.text(`${item.quantity}`, 125, y, { align: 'center' });
    doc.text(`Rs. ${item.price}`, 155, y, { align: 'right' });
    doc.text(`Rs. ${item.total}`, 190, y, { align: 'right' });
    y += 8;
  });

  // Total Summary
  doc.setLineWidth(0.5);
  doc.setDrawColor(30, 16, 60);
  doc.line(15, y, 195, y);
  y += 9;

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(12);
  doc.setTextColor(30, 16, 60);
  doc.text('TOTAL AMOUNT PAID:', 100, y);
  doc.setTextColor(180, 90, 0);
  doc.text(`Rs. ${order.totalAmount}`, 190, y, { align: 'right' });

  y += 14;
  doc.setFillColor(245, 245, 250);
  doc.roundedRect(15, y, 180, 14, 2, 2, 'F');
  doc.setFontSize(9.5);
  doc.setFont('helvetica', 'bold');
  const withinBudget = order.totalAmount <= order.allowedBudget;
  doc.setTextColor(withinBudget ? 0 : 200, withinBudget ? 120 : 0, 0);
  doc.text(
    `BUDGET CHECK: ${withinBudget ? 'PASSED (Within allocated budget)' : 'EXCEEDED BUDGET LIMIT'}`,
    105,
    y + 9,
    { align: 'center' }
  );

  // Footer
  doc.setFont('helvetica', 'italic');
  doc.setFontSize(9);
  doc.setTextColor(120, 120, 120);
  doc.text('Thank you for ordering with Family Fiesta!', 105, 280, { align: 'center' });

  doc.save(`Family_Fiesta_Order_Receipt_${order.orderNumber}.pdf`);
};
