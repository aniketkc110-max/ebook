import React, { useState, useEffect } from 'react';
import {
  Student,
  FoodItem,
  CartItem,
  Order,
  OrderStatus,
} from './types';
import { getStudentDisplayName } from './data/students';
import {
  getOrCreateDeviceId,
  getStudents,
  getMenuItems,
  saveMenuItems,
  getOrders,
  saveOrder,
  updateOrderStatus,
  deleteOrder,
  deleteCompletedOrders,
  getDeviceOrder,
  clearDeviceLock,
  resetAllData,
  deleteAllOrders,
  getStudentExistingOrder,
} from './services/storage';

import { Header } from './components/Header';
import { HomePage } from './components/HomePage';
import { MenuPage } from './components/MenuPage';
import { CartDrawer } from './components/CartDrawer';
import { OrderConfirmation } from './components/OrderConfirmation';
import { AlreadySubmittedView } from './components/AlreadySubmittedView';
import { AdminDashboard } from './components/admin/AdminDashboard';
import { AdminLoginModal } from './components/admin/AdminLoginModal';

export default function App() {
  const [currentView, setCurrentView] = useState<
    'home' | 'menu' | 'confirmation' | 'submitted' | 'admin'
  >('home');

  // Application Data States
  const [students, setStudents] = useState<Student[]>([]);
  const [menuItems, setMenuItems] = useState<FoodItem[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);

  // Selection & Cart States
  const [selectedStudent, setSelectedStudent] = useState<Student | null>(null);
  const [peopleCount, setPeopleCount] = useState<number>(1);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState<boolean>(false);
  const [activeOrder, setActiveOrder] = useState<Order | null>(null);

  // Admin Auth States
  const [isAdminLoggedIn, setIsAdminLoggedIn] = useState<boolean>(false);
  const [isAdminLoginModalOpen, setIsAdminLoginModalOpen] = useState<boolean>(false);

  // On App Mount: Initialize data & check One Device One Order rule
  useEffect(() => {
    getOrCreateDeviceId();
    const stList = getStudents();
    const menuList = getMenuItems();
    const orderList = getOrders();

    setStudents(stList);
    setMenuItems(menuList);
    setOrders(orderList);

    // Check URL path or hash for /admin
    if (window.location.pathname === '/admin' || window.location.hash === '#admin') {
      setIsAdminLoginModalOpen(true);
    }

    // Check if device already has a locked order
    const deviceLock = getDeviceOrder();
    if (deviceLock) {
      const existingOrder = orderList.find((o) => o.orderNumber === deviceLock.orderNumber);
      if (existingOrder) {
        setActiveOrder(existingOrder);
        setCurrentView('submitted');
      }
    }
  }, []);

  // Sync orders with local storage every 2 seconds for live status updates
  useEffect(() => {
    const timer = setInterval(() => {
      const freshOrders = getOrders();
      setOrders(freshOrders);
      if (activeOrder) {
        const updated = freshOrders.find((o) => o.orderNumber === activeOrder.orderNumber);
        if (updated) {
          setActiveOrder(updated);
        }
      }
    }, 2000);
    return () => clearInterval(timer);
  }, [activeOrder]);

  // Handler for student select in Home
  const handleSelectStudent = (student: Student | null) => {
    if (!student) {
      setSelectedStudent(null);
      return;
    }

    // Check if student already placed an order on any device
    const existing = getStudentExistingOrder(student.id);
    if (existing) {
      setActiveOrder(existing);
      setSelectedStudent(student);
      setCurrentView('submitted');
    } else {
      setSelectedStudent(student);
    }
  };

  // Handler to start ordering
  const handleStartOrdering = () => {
    if (!selectedStudent) return;
    setCart([]);
    setCurrentView('menu');
  };

  // Cart Handlers
  const handleAddToCart = (food: FoodItem, quantity: number) => {
    setCart((prev) => {
      const existingIndex = prev.findIndex((item) => item.food.id === food.id);
      if (existingIndex > -1) {
        const updated = [...prev];
        updated[existingIndex].quantity = quantity;
        return updated;
      } else {
        return [...prev, { food, quantity }];
      }
    });
  };

  const handleUpdateCartQuantity = (foodId: string, delta: number) => {
    setCart((prev) => {
      return prev
        .map((item) => {
          if (item.food.id === foodId) {
            const newQty = item.quantity + delta;
            return newQty > 0 ? { ...item, quantity: newQty } : null;
          }
          return item;
        })
        .filter(Boolean) as CartItem[];
    });
  };

  const handleRemoveCartItem = (foodId: string) => {
    setCart((prev) => prev.filter((item) => item.food.id !== foodId));
  };

  // Place Order Handler
  const handlePlaceOrder = () => {
    if (!selectedStudent || cart.length === 0) return;

    const devId = getOrCreateDeviceId();
    const orderNum = 'FLM-2026-' + Math.floor(1000 + Math.random() * 9000);
    const now = new Date();

    const orderItems = cart.map((c) => ({
      id: c.food.id,
      name: c.food.name,
      price: c.food.price,
      quantity: c.quantity,
      total: c.food.price * c.quantity,
    }));

    const totalAmount = orderItems.reduce((sum, i) => sum + i.total, 0);

    const newOrder: Order = {
      orderNumber: orderNum,
      studentId: selectedStudent.id,
      studentName: getStudentDisplayName(selectedStudent),
      parentName: selectedStudent.parentName,
      fullName: selectedStudent.fullName,
      deviceId: devId,
      peopleCount,
      allowedBudget: peopleCount * 220,
      items: orderItems,
      totalAmount,
      status: 'Pending',
      createdAt: now.toISOString(),
      dateDisplay: now.toLocaleDateString('en-IN', {
        day: 'numeric',
        month: 'short',
        year: 'numeric',
      }),
      timeDisplay: now.toLocaleTimeString('en-IN', {
        hour: '2-digit',
        minute: '2-digit',
      }),
    };

    saveOrder(newOrder);
    setOrders(getOrders());
    setActiveOrder(newOrder);
    setCart([]);
    setIsCartOpen(false);
    setCurrentView('confirmation');
  };

  // Admin Actions
  const handleAdminLoginSuccess = () => {
    setIsAdminLoggedIn(true);
    setIsAdminLoginModalOpen(false);
    setCurrentView('admin');
  };

  const handleAdminLogout = () => {
    setIsAdminLoggedIn(false);
    setCurrentView('home');
  };

  const handleUpdateOrderStatus = (orderNumber: string, status: OrderStatus) => {
    updateOrderStatus(orderNumber, status);
    setOrders(getOrders());
  };

  const handleDeleteOrder = (orderNumber: string) => {
    deleteOrder(orderNumber);
    setOrders(getOrders());
  };

  const handleDeleteCompletedOrders = () => {
    deleteCompletedOrders();
    setOrders(getOrders());
  };

  const handleSaveMenuItems = (items: FoodItem[]) => {
    saveMenuItems(items);
    setMenuItems(items);
  };

  const handleResetDeviceLock = () => {
    clearDeviceLock();
    setActiveOrder(null);
    setCurrentView('home');
  };

  const handleClearAllOrders = () => {
    deleteAllOrders();
    setOrders([]);
    setActiveOrder(null);
    setCurrentView('home');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-sky-100 via-sky-200 to-sky-300 text-purple-950 font-sans selection:bg-purple-300 selection:text-purple-950 relative overflow-x-hidden">
      
      {/* Global Background Ambient Sky Blue */}
      <div className="fixed top-0 left-1/2 -translate-x-1/2 w-[600px] h-[600px] bg-sky-300/40 rounded-full blur-[120px] pointer-events-none z-0" />

      {/* Header - shown on non-admin screens */}
      {currentView !== 'admin' && (
        <Header
          currentView={currentView}
          onNavigateHome={() => {
            if (currentView !== 'submitted') {
              setCurrentView('home');
            }
          }}
          onOpenAdmin={() => {
            if (isAdminLoggedIn) {
              setCurrentView('admin');
            } else {
              setIsAdminLoginModalOpen(true);
            }
          }}
          selectedStudentName={selectedStudent ? getStudentDisplayName(selectedStudent) : undefined}
          cartCount={cart.reduce((s, i) => s + i.quantity, 0)}
          onOpenCart={() => setIsCartOpen(true)}
        />
      )}

      {/* View Switcher */}
      <main className="relative z-10">
        {currentView === 'home' && (
          <HomePage
            students={students}
            selectedStudent={selectedStudent}
            onSelectStudent={handleSelectStudent}
            peopleCount={peopleCount}
            onChangePeopleCount={setPeopleCount}
            onStartOrdering={handleStartOrdering}
            onOpenAdmin={() => setIsAdminLoginModalOpen(true)}
          />
        )}

        {currentView === 'menu' && selectedStudent && (
          <MenuPage
            menuItems={menuItems}
            cart={cart}
            selectedStudent={selectedStudent}
            peopleCount={peopleCount}
            onAddToCart={handleAddToCart}
            onOpenCart={() => setIsCartOpen(true)}
          />
        )}

        {currentView === 'confirmation' && activeOrder && (
          <OrderConfirmation
            order={activeOrder}
            onRefreshOrder={(up) => setActiveOrder(up)}
          />
        )}

        {currentView === 'submitted' && activeOrder && (
          <AlreadySubmittedView
            order={activeOrder}
            onRefreshOrder={(up) => setActiveOrder(up)}
          />
        )}

        {currentView === 'admin' && isAdminLoggedIn && (
          <AdminDashboard
            orders={orders}
            students={students}
            menuItems={menuItems}
            onUpdateOrderStatus={handleUpdateOrderStatus}
            onDeleteOrder={handleDeleteOrder}
            onDeleteCompletedOrders={handleDeleteCompletedOrders}
            onSaveMenuItems={handleSaveMenuItems}
            onResetDeviceLock={handleResetDeviceLock}
            onClearAllOrders={handleClearAllOrders}
            onExitAdmin={handleAdminLogout}
            onLogoutAdmin={handleAdminLogout}
          />
        )}
      </main>

      {/* Slide-over Cart Drawer */}
      {selectedStudent && (
        <CartDrawer
          isOpen={isCartOpen}
          onClose={() => setIsCartOpen(false)}
          cart={cart}
          onUpdateQuantity={handleUpdateCartQuantity}
          onRemoveItem={handleRemoveCartItem}
          selectedStudent={selectedStudent}
          peopleCount={peopleCount}
          onPlaceOrder={handlePlaceOrder}
        />
      )}

      {/* Password Modal for Admin */}
      <AdminLoginModal
        isOpen={isAdminLoginModalOpen}
        onClose={() => setIsAdminLoginModalOpen(false)}
        onLoginSuccess={handleAdminLoginSuccess}
      />

    </div>
  );
}
