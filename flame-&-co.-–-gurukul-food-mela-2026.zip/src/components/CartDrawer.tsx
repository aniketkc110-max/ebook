import React, { useState } from 'react';
import { CartItem, Student } from '../types';
import { X, Trash2, Plus, Minus, ShoppingBag, ShieldCheck, AlertTriangle, ArrowRight, User, HelpCircle, CheckCircle2 } from 'lucide-react';
import confetti from 'canvas-confetti';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  cart: CartItem[];
  onUpdateQuantity: (foodId: string, delta: number) => void;
  onRemoveItem: (foodId: string) => void;
  selectedStudent: Student;
  peopleCount: number;
  onPlaceOrder: () => void;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({
  isOpen,
  onClose,
  cart,
  onUpdateQuantity,
  onRemoveItem,
  selectedStudent,
  peopleCount,
  onPlaceOrder,
}) => {
  const [showConfirmModal, setShowConfirmModal] = useState(false);

  if (!isOpen) return null;

  const allowedBudget = peopleCount * 220;
  const currentTotal = cart.reduce((sum, item) => sum + item.food.price * item.quantity, 0);
  const isExceeded = currentTotal > allowedBudget;
  const exceededAmount = currentTotal - allowedBudget;
  const remainingBudget = allowedBudget - currentTotal;
  const totalItemsCount = cart.reduce((sum, item) => sum + item.quantity, 0);

  const handleCheckout = () => {
    if (cart.length === 0 || isExceeded) return;
    setShowConfirmModal(false);
    try {
      confetti({
        particleCount: 100,
        spread: 70,
        origin: { y: 0.6 },
      });
    } catch (e) {
      // ignore
    }
    onPlaceOrder();
  };

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      
      <div className="w-full max-w-md bg-sky-50 border-l border-purple-300 h-full flex flex-col justify-between relative animate-in slide-in-from-right duration-300">
        
        {/* Header */}
        <div className="p-4 sm:p-5 bg-sky-100 border-b border-purple-300 flex items-center justify-between flex-shrink-0">
          <div className="flex items-center space-x-3">
            <div className="p-2.5 rounded-xl bg-purple-800 text-white shadow-md">
              <ShoppingBag className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-xl font-black text-purple-950">Your Cart</h2>
              <p className="text-xs text-purple-800 font-semibold">
                {selectedStudent.firstName} ({selectedStudent.parentName}) • {peopleCount} {peopleCount === 1 ? 'Person' : 'People'}
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-xl bg-purple-100 border border-purple-300 text-purple-950 hover:bg-purple-200 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Cart Item List */}
        <div className="p-4 space-y-3 overflow-y-auto custom-scrollbar flex-1">
          
          {cart.length === 0 ? (
            <div className="py-16 text-center space-y-4">
              <div className="w-20 h-20 rounded-full bg-purple-100 border border-purple-300 flex items-center justify-center mx-auto text-purple-800">
                <ShoppingBag className="w-10 h-10" />
              </div>
              <div className="space-y-1">
                <p className="text-lg font-bold text-purple-950">Your cart is empty</p>
                <p className="text-xs text-purple-800 max-w-xs mx-auto font-medium">
                  Browse Family Fiesta menu items and add your favorite dishes to start ordering.
                </p>
              </div>
            </div>
          ) : (
            cart.map((item) => {
              const itemTotal = item.food.price * item.quantity;
              return (
                <div
                  key={item.food.id}
                  className="p-3 rounded-2xl bg-sky-100/90 border border-purple-300 flex items-center space-x-3 shadow-md"
                >
                  <img
                    src={item.food.image}
                    alt={item.food.name}
                    className="w-16 h-16 rounded-xl object-cover flex-shrink-0 border border-purple-300"
                  />

                  <div className="flex-1 min-w-0">
                    <h3 className="text-sm font-bold text-purple-950 truncate">
                      {item.food.name}
                    </h3>
                    <p className="text-xs text-purple-800 font-medium">₹{item.food.price} each</p>
                    <p className="text-sm font-black text-purple-950 mt-0.5">
                      ₹{itemTotal}
                    </p>
                  </div>

                  {/* Quantity controls */}
                  <div className="flex flex-col items-end space-y-2">
                    <div className="flex items-center space-x-1 bg-white border border-purple-300 rounded-xl p-1">
                      <button
                        type="button"
                        onClick={() => onUpdateQuantity(item.food.id, -1)}
                        className="w-6 h-6 rounded-lg bg-purple-200 text-purple-950 flex items-center justify-center hover:bg-purple-300 cursor-pointer"
                      >
                        <Minus className="w-3 h-3" />
                      </button>
                      <span className="w-6 text-center text-xs font-bold text-purple-950">
                        {item.quantity}
                      </span>
                      <button
                        type="button"
                        onClick={() => onUpdateQuantity(item.food.id, 1)}
                        className="w-6 h-6 rounded-lg bg-purple-800 text-white flex items-center justify-center hover:bg-purple-900 cursor-pointer"
                      >
                        <Plus className="w-3 h-3" />
                      </button>
                    </div>

                    <button
                      type="button"
                      onClick={() => onRemoveItem(item.food.id)}
                      className="text-red-600 hover:text-red-700 text-xs font-bold flex items-center space-x-1 cursor-pointer"
                    >
                      <Trash2 className="w-3 h-3" />
                      <span>Remove</span>
                    </button>
                  </div>
                </div>
              );
            })
          )}

        </div>

        {/* Footer with Budget Protection Analysis */}
        <div className="p-4 sm:p-5 bg-sky-100 border-t border-purple-300 space-y-4 flex-shrink-0">
          
          {/* Budget Protection Status Banner */}
          <div
            className={`p-4 rounded-2xl border transition-all ${
              isExceeded
                ? 'bg-red-100 border-red-300 text-red-900'
                : 'bg-emerald-100 border-emerald-300 text-emerald-950'
            }`}
          >
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center space-x-2 font-bold text-sm">
                {isExceeded ? (
                  <>
                    <AlertTriangle className="w-5 h-5 text-red-600 animate-bounce" />
                    <span className="text-red-800">⚠️ Budget Exceeded</span>
                  </>
                ) : (
                  <>
                    <ShieldCheck className="w-5 h-5 text-emerald-700" />
                    <span className="text-emerald-900">✅ Within Budget</span>
                  </>
                )}
              </div>
              <span className="text-xs font-bold px-2.5 py-0.5 rounded-full bg-white/60 border border-purple-200 text-purple-950">
                ₹220 x {peopleCount} = ₹{allowedBudget}
              </span>
            </div>

            <div className="grid grid-cols-3 gap-2 text-center text-xs pt-2 border-t border-purple-200">
              <div>
                <div className="text-[10px] opacity-80 font-bold">Allowed Budget</div>
                <div className="font-black text-sm text-purple-950">₹{allowedBudget}</div>
              </div>
              <div>
                <div className="text-[10px] opacity-80 font-bold">Current Total</div>
                <div className="font-black text-sm text-purple-950">₹{currentTotal}</div>
              </div>
              <div>
                <div className="text-[10px] opacity-80 font-bold">
                  {isExceeded ? 'Exceeded By' : 'Remaining'}
                </div>
                <div
                  className={`font-black text-sm ${
                    isExceeded ? 'text-red-700' : 'text-emerald-800'
                  }`}
                >
                  ₹{isExceeded ? exceededAmount : remainingBudget}
                </div>
              </div>
            </div>

            {isExceeded && (
              <p className="text-[11px] text-red-800 mt-2 text-center font-bold">
                Please adjust item quantities or remove dishes to stay within ₹{allowedBudget}.
              </p>
            )}
          </div>

          {/* Place Order CTA Button */}
          <button
            type="button"
            disabled={cart.length === 0 || isExceeded}
            onClick={() => setShowConfirmModal(true)}
            className={`w-full py-4 px-6 rounded-2xl font-black text-base uppercase tracking-wider flex items-center justify-center space-x-3 transition-all duration-300 shadow-xl ${
              cart.length > 0 && !isExceeded
                ? 'bg-gradient-to-r from-purple-700 via-purple-800 to-purple-900 text-white shadow-purple-950/20 hover:brightness-110 active:scale-[0.98] ring-2 ring-purple-500/50 cursor-pointer animate-pulse'
                : 'bg-sky-200 border border-purple-300 text-purple-400 cursor-not-allowed'
            }`}
          >
            <span>Place Order (₹{currentTotal})</span>
            <ArrowRight className="w-5 h-5" />
          </button>

        </div>

      </div>

      {/* Are You Sure / Confirmation Modal */}
      {showConfirmModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
          <div className="w-full max-w-sm bg-sky-50 border border-purple-300 rounded-3xl p-5 shadow-2xl space-y-4 text-center animate-in zoom-in-95 duration-200">
            <div className="w-14 h-14 rounded-2xl bg-purple-100 border border-purple-300 text-purple-800 flex items-center justify-center mx-auto shadow-md">
              <HelpCircle className="w-8 h-8" />
            </div>

            <div className="space-y-1">
              <h3 className="text-xl font-black text-purple-950">Are You Sure?</h3>
              <p className="text-xs text-purple-800 font-bold">
                Please confirm your order placement details:
              </p>
            </div>

            {/* Order Summary Card */}
            <div className="p-3.5 rounded-2xl bg-sky-100 border border-purple-300 text-left space-y-2 text-xs">
              <div className="flex justify-between text-purple-900 font-bold">
                <span>Student:</span>
                <span className="text-purple-950 font-black">{selectedStudent.firstName} ({selectedStudent.parentName})</span>
              </div>
              <div className="flex justify-between text-purple-900 font-bold">
                <span>Total Items:</span>
                <span className="text-purple-950 font-black">{totalItemsCount} {totalItemsCount === 1 ? 'Dish' : 'Dishes'}</span>
              </div>
              <div className="flex justify-between text-purple-900 font-bold border-t border-purple-200 pt-2 text-sm">
                <span>Total Amount:</span>
                <span className="text-purple-950 font-black">₹{currentTotal}</span>
              </div>
              <div className="text-[10px] text-emerald-800 font-extrabold text-right pt-0.5">
                ✓ Within Allowed Budget (₹{allowedBudget})
              </div>
            </div>

            {/* Action Buttons */}
            <div className="pt-2 space-y-2">
              <button
                type="button"
                onClick={handleCheckout}
                className="w-full py-3.5 px-4 rounded-xl bg-gradient-to-r from-purple-700 via-purple-800 to-purple-900 hover:brightness-110 text-white font-black text-sm uppercase tracking-wider shadow-lg cursor-pointer transition-all active:scale-95 flex items-center justify-center space-x-2"
              >
                <CheckCircle2 className="w-5 h-5" />
                <span>Yes, Confirm Order Placement</span>
              </button>

              <button
                type="button"
                onClick={() => setShowConfirmModal(false)}
                className="w-full py-2.5 px-4 rounded-xl bg-purple-100 hover:bg-purple-200 border border-purple-300 text-purple-950 font-black text-xs uppercase tracking-wider cursor-pointer transition-all active:scale-95"
              >
                No, Back to Cart
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
