import React, { useState, useRef, useEffect } from 'react';
import { Student } from '../types';
import { getStudentDisplayName } from '../data/students';
import { Search, UserCheck, ChevronDown, Check, User } from 'lucide-react';

interface StudentSelectProps {
  students: Student[];
  selectedStudent: Student | null;
  onSelectStudent: (student: Student | null) => void;
  disabled?: boolean;
}

export const StudentSelect: React.FC<StudentSelectProps> = ({
  students,
  selectedStudent,
  onSelectStudent,
  disabled = false,
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const dropdownRef = useRef<HTMLDivElement>(null);

  // Filter students based on search query matching first name or parent name
  const filteredStudents = students.filter((s) => {
    const label = getStudentDisplayName(s).toLowerCase();
    const query = searchQuery.toLowerCase().trim();
    return label.includes(query) || s.firstName.toLowerCase().includes(query) || s.parentName.toLowerCase().includes(query);
  });

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  return (
    <div className="relative w-full" ref={dropdownRef}>
      <label className="block text-xs font-bold text-purple-950 uppercase tracking-wider mb-2">
        Select Approved Student <span className="text-red-500">*</span>
      </label>

      {/* Selected Student Trigger Button */}
      <button
        type="button"
        disabled={disabled}
        onClick={() => setIsOpen(!isOpen)}
        className={`w-full text-left px-4 py-3.5 rounded-xl flex items-center justify-between border transition-all duration-200 ${
          isOpen
            ? 'border-purple-500 bg-sky-100 ring-2 ring-purple-400/50'
            : selectedStudent
            ? 'border-purple-400 bg-sky-100 text-purple-950 shadow-md'
            : 'border-purple-300 bg-sky-50 text-purple-950 hover:border-purple-400'
        } ${disabled ? 'opacity-60 cursor-not-allowed' : 'cursor-pointer'}`}
      >
        <div className="flex items-center space-x-3 overflow-hidden">
          <div className="p-2 rounded-lg bg-gradient-to-br from-purple-700 to-purple-900 text-white flex-shrink-0">
            <User className="w-5 h-5" />
          </div>
          <div className="truncate">
            {selectedStudent ? (
              <span className="font-bold text-lg text-purple-950">
                {getStudentDisplayName(selectedStudent)}
              </span>
            ) : (
              <span className="text-purple-800 font-medium">Search or select student name...</span>
            )}
          </div>
        </div>
        <ChevronDown
          className={`w-5 h-5 text-purple-800 transition-transform duration-200 flex-shrink-0 ${
            isOpen ? 'rotate-180 text-purple-950' : ''
          }`}
        />
      </button>

      {/* Dropdown Menu */}
      {isOpen && !disabled && (
        <div className="absolute z-50 left-0 right-0 mt-2 bg-sky-50 border border-purple-300 rounded-2xl shadow-2xl backdrop-blur-xl overflow-hidden animate-in fade-in duration-150">
          {/* Search Box inside dropdown */}
          <div className="p-3 border-b border-purple-200 bg-sky-100">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-purple-700" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Type First Name or Parent Name..."
                className="w-full pl-9 pr-4 py-2.5 bg-white border border-purple-300 rounded-xl text-purple-950 placeholder-purple-400 text-sm focus:outline-none focus:border-purple-500 focus:ring-1 focus:ring-purple-500"
                autoFocus
              />
            </div>
            <p className="text-[11px] text-purple-800 font-medium mt-1.5 px-1">
              Select name from approved directory. Custom typing disabled.
            </p>
          </div>

          {/* Student List */}
          <div className="max-h-64 overflow-y-auto divide-y divide-purple-100 custom-scrollbar">
            {filteredStudents.length > 0 ? (
              filteredStudents.map((student) => {
                const isSelected = selectedStudent?.id === student.id;
                const displayName = getStudentDisplayName(student);

                return (
                  <button
                    key={student.id}
                    type="button"
                    onClick={() => {
                      onSelectStudent(student);
                      setIsOpen(false);
                      setSearchQuery('');
                    }}
                    className={`w-full px-4 py-3 text-left flex items-center justify-between transition-colors duration-150 cursor-pointer ${
                      isSelected
                        ? 'bg-purple-200 text-purple-950 font-bold'
                        : 'text-purple-950 hover:bg-sky-100'
                    }`}
                  >
                    <div className="flex items-center space-x-3">
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold ${
                        isSelected ? 'bg-purple-800 text-white' : 'bg-purple-200 text-purple-900'
                      }`}>
                        {student.firstName[0]}
                      </div>
                      <div>
                        <div className="font-bold text-base text-purple-950">{displayName}</div>
                        <div className="text-xs text-purple-800">{student.grade}</div>
                      </div>
                    </div>

                    {isSelected && (
                      <span className="p-1 rounded-full bg-purple-800 text-white">
                        <Check className="w-4 h-4" />
                      </span>
                    )}
                  </button>
                );
              })
            ) : (
              <div className="px-4 py-6 text-center text-purple-800 font-medium text-sm">
                No matching student found in Gurukul roster.
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
