import React, { useEffect, useState } from 'react';
import { Order, OrderStatus } from '../types';
import { CheckCircle2, Clock, ChefHat, Sparkles, Flame, Ticket, Download, Printer, Copy, Check, FileText } from 'lucide-react';
import { generateAndDownloadPDFReceipt } from '../utils/pdfGenerator';

interface OrderConfirmationProps {
  order: Order;
  onRefreshOrder?: (updated: Order) => void;
}

export const OrderConfirmation: React.FC<OrderConfirmationProps> = ({ order, onRefreshOrder }) => {
  const [currentOrder, setCurrentOrder] = useState<Order>(order);
  const [copied, setCopied] = useState(false);

  const handleDownloadReceipt = () => {
    const cleanStudentName = currentOrder.studentName.replace(/\s*\(.*\)/, '').trim();
    const receiptText = `=========================================
  FAMILY FIESTA - RECEIPT
=========================================
Order Token  : #${currentOrder.orderNumber}
Date & Time  : ${currentOrder.dateDisplay || ''} ${currentOrder.timeDisplay}
Status       : ${currentOrder.status}

---------------- STUDENT DETAILS ----------------
Student Name : ${cleanStudentName}
Parent Name  : ${currentOrder.parentName}
Full Name    : ${currentOrder.fullName}
Student ID   : ${currentOrder.studentId}
Group Size   : ${currentOrder.peopleCount} Person(s)
Budget Limit : ₹${currentOrder.allowedBudget}

---------------- ORDERED ITEMS ------------------
${currentOrder.items.map((i) => `${i.quantity}x ${i.name.padEnd(24)} ₹${i.total}`).join('\n')}

-------------------------------------------------
TOTAL AMOUNT : ₹${currentOrder.totalAmount}
BUDGET CHECK : ${currentOrder.totalAmount <= currentOrder.allowedBudget ? 'PASSED (Within Budget)' : 'EXCEEDED BUDGET'}
=========================================
Thank you for ordering from Family Fiesta!
`;

    const blob = new Blob([receiptText], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `Family_Fiesta_Receipt_Order_${currentOrder.orderNumber}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleCopyReceipt = () => {
    const cleanStudentName = currentOrder.studentName.replace(/\s*\(.*\)/, '').trim();
    const receiptText = `FAMILY FIESTA RECEIPT
Order #${currentOrder.orderNumber}
Student: ${cleanStudentName} (${currentOrder.studentId})
Parent: ${currentOrder.parentName}
Date: ${currentOrder.dateDisplay || ''} ${currentOrder.timeDisplay}
Status: ${currentOrder.status}
Items:
${currentOrder.items.map((i) => ` - ${i.quantity}x ${i.name} (₹${i.total})`).join('\n')}
Total: ₹${currentOrder.totalAmount}`;

    navigator.clipboard.writeText(receiptText).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 3000);
    });
  };

  const handlePrintReceipt = () => {
    window.print();
  };

  // Poll local storage every 2 seconds to support real-time status updates when changed in Admin panel
  useEffect(() => {
    const interval = setInterval(() => {
      try {
        const raw = localStorage.getItem('flame_co_orders_v2');
        if (raw) {
          const orders: Order[] = JSON.parse(raw);
          const found = orders.find((o) => o.orderNumber === order.orderNumber);
          if (found && (found.status !== currentOrder.status || found.totalAmount !== currentOrder.totalAmount)) {
            setCurrentOrder(found);
            if (onRefreshOrder) onRefreshOrder(found);
          }
        }
      } catch (e) {
        // ignore
      }
    }, 2000);

    return () => clearInterval(interval);
  }, [order.orderNumber, currentOrder.status, currentOrder.totalAmount, onRefreshOrder]);

  const statuses: { label: OrderStatus; desc: string; icon: React.ReactNode }[] = [
    { label: 'Pending', desc: 'Order received by Family Fiesta', icon: <Clock className="w-4 h-4" /> },
    { label: 'Preparing', desc: 'Sizzling in kitchen...', icon: <ChefHat className="w-4 h-4" /> },
    { label: 'Ready', desc: 'Ready at Family Fiesta Counter!', icon: <Sparkles className="w-4 h-4" /> },
    { label: 'Completed', desc: 'Served & Enjoyed!', icon: <CheckCircle2 className="w-4 h-4" /> },
  ];

  const currentStepIndex = statuses.findIndex((s) => s.label === currentOrder.status);

  return (
    <div className="min-h-[calc(100vh-70px)] p-4 sm:p-6 max-w-md mx-auto space-y-5 animate-in fade-in duration-300">
      
      {/* Top Banner Success */}
      <div className="text-center p-6 rounded-3xl bg-sky-50 border border-purple-300 shadow-xl space-y-3 relative overflow-hidden">
        <div className="w-16 h-16 rounded-full bg-emerald-100 border border-emerald-400 flex items-center justify-center mx-auto text-emerald-700">
          <CheckCircle2 className="w-10 h-10 animate-bounce" />
        </div>

        <div>
          <span className="text-xs font-bold text-emerald-800 uppercase tracking-widest px-3 py-1 rounded-full bg-emerald-100 border border-emerald-300">
            ✅ Order Successfully Placed
          </span>
          <h2 className="text-2xl font-black text-purple-950 mt-2">
            Thank you for ordering from Family Fiesta!
          </h2>
          <p className="text-xs text-purple-800 font-bold mt-1">
            Order Token #{currentOrder.orderNumber}
          </p>
        </div>
      </div>

      {/* Live Order Tracker Progress Card */}
      <div className="p-5 rounded-3xl bg-sky-50 border border-purple-300 shadow-md space-y-4">
        <div className="flex items-center justify-between border-b border-purple-200 pb-3">
          <span className="text-xs font-bold text-purple-950 uppercase tracking-wider flex items-center space-x-1.5">
            <Flame className="w-4 h-4 text-purple-700" />
            <span>Live Kitchen Status</span>
          </span>
          <span className="text-xs font-extrabold text-purple-950 px-2.5 py-0.5 rounded-full bg-purple-200 border border-purple-300">
            {currentOrder.status}
          </span>
        </div>

        {/* Step Progress Visualizer */}
        <div className="space-y-3 pt-1">
          {statuses.map((st, index) => {
            const isDone = index <= currentStepIndex;
            const isCurrent = index === currentStepIndex;

            return (
              <div key={st.label} className="flex items-start space-x-3">
                <div
                  className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold transition-all ${
                    isDone
                      ? 'bg-purple-800 text-white ring-2 ring-purple-400'
                      : 'bg-purple-100 text-purple-400 border border-purple-300'
                  }`}
                >
                  {st.icon}
                </div>

                <div className="flex-1 pb-2">
                  <div className="flex items-center justify-between">
                    <span
                      className={`text-sm font-extrabold ${
                        isCurrent
                          ? 'text-purple-950 text-base font-black'
                          : isDone
                          ? 'text-purple-950'
                          : 'text-purple-400'
                      }`}
                    >
                      {st.label}
                    </span>
                    {isCurrent && (
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-purple-800 text-white animate-pulse">
                        Active
                      </span>
                    )}
                  </div>
                  <p className="text-xs text-purple-800 font-medium">{st.desc}</p>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Ticket Receipt Summary */}
      <div className="printable-receipt p-5 rounded-3xl bg-sky-50 border border-purple-300 shadow-xl space-y-4 relative">
        <div className="flex items-center justify-between border-b border-purple-200 pb-3">
          <div className="flex items-center space-x-2 text-purple-950 text-sm font-bold">
            <Ticket className="w-4 h-4 text-purple-700" />
            <span>Order Receipt</span>
          </div>
          <span className="text-xs text-purple-800 font-bold">
            {currentOrder.timeDisplay}
          </span>
        </div>

        {/* Student metadata */}
        <div className="grid grid-cols-2 gap-3 text-xs bg-sky-100 p-3 rounded-2xl border border-purple-200">
          <div>
            <span className="text-purple-800 text-[10px] block font-bold">Student Name</span>
            <span className="font-extrabold text-purple-950">{currentOrder.studentName}</span>
          </div>
          <div>
            <span className="text-purple-800 text-[10px] block font-bold">Student ID</span>
            <span className="font-extrabold text-purple-950">{currentOrder.studentId}</span>
          </div>
          <div>
            <span className="text-purple-800 text-[10px] block font-bold">Group Size</span>
            <span className="font-extrabold text-purple-950">{currentOrder.peopleCount} People</span>
          </div>
          <div>
            <span className="text-purple-800 text-[10px] block font-bold">Budget Limit</span>
            <span className="font-extrabold text-purple-950">₹{currentOrder.allowedBudget}</span>
          </div>
        </div>

        {/* Items List */}
        <div className="space-y-2 border-t border-purple-200 pt-3">
          <div className="text-xs font-bold text-purple-950 uppercase tracking-wider mb-2">
            Ordered Food Items
          </div>
          {currentOrder.items.map((item) => (
            <div key={item.id} className="flex items-center justify-between text-xs py-1">
              <span className="text-purple-950 font-bold">
                {item.quantity}x {item.name}
              </span>
              <span className="font-black text-purple-950">₹{item.total}</span>
            </div>
          ))}
        </div>

        {/* Total */}
        <div className="border-t border-purple-300 pt-3 flex items-center justify-between text-base font-black">
          <span className="text-purple-950">Total Amount</span>
          <span className="text-xl text-purple-950">₹{currentOrder.totalAmount}</span>
        </div>

        {/* Receipt Action Buttons (PDF / TXT / Copy) */}
        <div className="no-print pt-3 border-t border-purple-200 grid grid-cols-3 gap-2">
          <button
            type="button"
            onClick={() => generateAndDownloadPDFReceipt(currentOrder)}
            className="px-3 py-2.5 rounded-xl bg-purple-800 hover:bg-purple-900 text-white font-black text-xs uppercase tracking-wider flex items-center justify-center space-x-1.5 shadow-md active:scale-95 transition-all cursor-pointer"
            title="Download official PDF receipt"
          >
            <FileText className="w-3.5 h-3.5" />
            <span>Download PDF</span>
          </button>

          <button
            type="button"
            onClick={handleDownloadReceipt}
            className="px-3 py-2.5 rounded-xl bg-purple-100 hover:bg-purple-200 text-purple-950 font-extrabold text-xs uppercase tracking-wider flex items-center justify-center space-x-1.5 border border-purple-300 active:scale-95 transition-all cursor-pointer"
            title="Download receipt as text file"
          >
            <Download className="w-3.5 h-3.5" />
            <span>TXT</span>
          </button>

          <button
            type="button"
            onClick={handleCopyReceipt}
            className="px-3 py-2.5 rounded-xl bg-purple-100 hover:bg-purple-200 text-purple-950 font-extrabold text-xs uppercase tracking-wider flex items-center justify-center space-x-1.5 border border-purple-300 active:scale-95 transition-all cursor-pointer"
            title="Copy receipt summary text"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-700" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copied ? 'Done' : 'Copy'}</span>
          </button>
        </div>
      </div>

    </div>
  );
};
