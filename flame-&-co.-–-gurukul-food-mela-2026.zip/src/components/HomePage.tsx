import React, { useState } from 'react';
import { Student } from '../types';
import { StudentSelect } from './StudentSelect';
import { Logo } from './Logo';
import { Users, Wallet, ArrowRight, ShieldAlert, Sparkles, CheckCircle2 } from 'lucide-react';

interface HomePageProps {
  students: Student[];
  selectedStudent: Student | null;
  onSelectStudent: (student: Student | null) => void;
  peopleCount: number;
  onChangePeopleCount: (count: number) => void;
  onStartOrdering: () => void;
  onOpenAdmin: () => void;
}

export const HomePage: React.FC<HomePageProps> = ({
  students,
  selectedStudent,
  onSelectStudent,
  peopleCount,
  onChangePeopleCount,
  onStartOrdering,
  onOpenAdmin,
}) => {
  const allowedBudget = peopleCount * 220;

  return (
    <div className="min-h-[calc(100vh-65px)] flex flex-col justify-between p-4 sm:p-6 max-w-md mx-auto relative z-10">
      
      {/* Top Main Section */}
      <div className="space-y-6 pt-2">
        
        {/* Brand Hero Card */}
        <div className="text-center space-y-3 p-6 rounded-3xl bg-sky-50/90 border border-purple-300 shadow-xl backdrop-blur-xl relative overflow-hidden">
          {/* Subtle sky/purple glow */}
          <div className="absolute top-0 left-1/2 -translate-x-1/2 w-48 h-48 bg-sky-200/50 rounded-full blur-3xl pointer-events-none" />

          {/* Logo Emblem */}
          <div className="flex justify-center mx-auto">
            <Logo size="xl" />
          </div>

          {/* Name & Subtitle */}
          <div>
            <h1 className="text-3xl font-black text-purple-950 tracking-tight">
              Family Fiesta
            </h1>
          </div>

          <div className="pt-2 border-t border-purple-200 text-xs text-purple-900 font-medium">
            Welcome! Select your registered name and group size to calculate your budget and start ordering.
          </div>
        </div>

        {/* Student Registration Section */}
        <div className="p-5 rounded-2xl bg-sky-50/90 border border-purple-300 shadow-lg space-y-4">
          <div className="flex items-center space-x-2 text-purple-950 font-bold text-sm border-b border-purple-200 pb-2">
            <Sparkles className="w-4 h-4 text-purple-700" />
            <span>Student Registration</span>
          </div>

          {/* Student Searchable Selector */}
          <StudentSelect
            students={students}
            selectedStudent={selectedStudent}
            onSelectStudent={onSelectStudent}
          />

          {selectedStudent && (
            <div className="p-3 rounded-xl bg-purple-100/80 border border-purple-300 flex items-center space-x-3 animate-in fade-in">
              <CheckCircle2 className="w-5 h-5 text-purple-700 flex-shrink-0" />
              <div className="text-xs text-purple-950">
                Registered student identified as <span className="font-bold text-purple-950">{selectedStudent.firstName}</span> ({selectedStudent.parentName}).
              </div>
            </div>
          )}
        </div>

        {/* People Count Selector */}
        <div className="p-5 rounded-2xl bg-sky-50/90 border border-purple-300 shadow-lg space-y-3">
          <div className="flex items-center justify-between">
            <label className="text-xs font-bold text-purple-950 uppercase tracking-wider flex items-center space-x-1.5">
              <Users className="w-4 h-4 text-purple-700" />
              <span>Number of People</span>
            </label>
            <span className="text-xs text-purple-800 font-semibold">(₹220 per person)</span>
          </div>

          <div className="grid grid-cols-5 gap-2">
            {[1, 2, 3, 4, 5].map((num) => {
              const isSelected = peopleCount === num;
              return (
                <button
                  key={num}
                  type="button"
                  onClick={() => onChangePeopleCount(num)}
                  className={`py-3 rounded-xl font-bold text-base transition-all duration-200 flex flex-col items-center justify-center cursor-pointer ${
                    isSelected
                      ? 'bg-gradient-to-b from-purple-700 to-purple-900 text-white shadow-lg ring-2 ring-purple-600 scale-105'
                      : 'bg-sky-100 border border-purple-300 text-purple-950 hover:bg-sky-200'
                  }`}
                >
                  <span>{num}</span>
                  <span className="text-[9px] font-medium text-purple-900">{num === 1 ? 'Person' : 'People'}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Budget Calculator Card */}
        <div className="p-5 rounded-2xl bg-gradient-to-r from-sky-200 via-sky-100 to-purple-100 border border-purple-300 shadow-lg relative overflow-hidden">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center space-x-2 text-purple-950 font-bold text-sm">
              <Wallet className="w-4 h-4 text-purple-700" />
              <span>Budget Calculator</span>
            </div>
            <span className="text-xs px-2.5 py-0.5 rounded-full bg-purple-200 text-purple-950 border border-purple-300 font-extrabold">
              Fixed ₹220/head
            </span>
          </div>

          <div className="grid grid-cols-3 gap-2 text-center pt-2 border-t border-purple-200">
            <div className="p-2 rounded-xl bg-white/70 border border-purple-200">
              <div className="text-[10px] text-purple-900 uppercase tracking-wider font-bold">Max Budget</div>
              <div className="text-xl font-black text-purple-950 mt-0.5">₹{allowedBudget}</div>
            </div>

            <div className="p-2 rounded-xl bg-white/70 border border-purple-200">
              <div className="text-[10px] text-purple-900 uppercase tracking-wider font-bold">Current Total</div>
              <div className="text-xl font-black text-purple-950 mt-0.5">₹0</div>
            </div>

            <div className="p-2 rounded-xl bg-white/70 border border-purple-200">
              <div className="text-[10px] text-purple-900 uppercase tracking-wider font-bold">Remaining</div>
              <div className="text-xl font-black text-purple-800 mt-0.5">₹{allowedBudget}</div>
            </div>
          </div>
        </div>

      </div>

      {/* Bottom CTA Button */}
      <div className="pt-6 pb-2 space-y-3">
        <button
          type="button"
          disabled={!selectedStudent}
          onClick={onStartOrdering}
          className={`w-full py-4 px-6 rounded-2xl font-black text-lg tracking-wide uppercase flex items-center justify-center space-x-3 transition-all duration-300 shadow-xl ${
            selectedStudent
              ? 'bg-gradient-to-r from-purple-700 via-purple-800 to-purple-900 text-white shadow-purple-950/20 hover:brightness-110 active:scale-[0.98] ring-2 ring-purple-500/50 cursor-pointer animate-pulse'
              : 'bg-sky-200 border border-purple-300 text-purple-600/60 cursor-not-allowed'
          }`}
        >
          <span>Start Ordering</span>
          <ArrowRight className="w-5 h-5" />
        </button>

        {!selectedStudent && (
          <p className="text-center text-xs text-purple-900 font-bold">
            * Please select your student name to unlock the menu.
          </p>
        )}

        <div className="text-center text-[11px] text-purple-800 font-semibold pt-2 flex items-center justify-center space-x-1">
          <span>Family Fiesta</span>
        </div>
      </div>

    </div>
  );
};
