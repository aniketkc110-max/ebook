import React, { useState } from 'react';
import { FoodItem, CartItem, Student } from '../types';
import { Sparkles, ShoppingBag, ShieldCheck, AlertTriangle, ChevronRight, User, Utensils, Flame } from 'lucide-react';
import { FoodDetailModal } from './FoodDetailModal';

interface MenuPageProps {
  menuItems: FoodItem[];
  cart: CartItem[];
  selectedStudent: Student;
  peopleCount: number;
  onAddToCart: (food: FoodItem, quantity: number) => void;
  onOpenCart: () => void;
}

export const MenuPage: React.FC<MenuPageProps> = ({
  menuItems,
  cart,
  selectedStudent,
  peopleCount,
  onAddToCart,
  onOpenCart,
}) => {
  const [selectedFoodForModal, setSelectedFoodForModal] = useState<FoodItem | null>(null);

  const allowedBudget = peopleCount * 220;
  const currentTotal = cart.reduce((sum, item) => sum + item.food.price * item.quantity, 0);
  const totalCartCount = cart.reduce((sum, item) => sum + item.quantity, 0);
  const isExceeded = currentTotal > allowedBudget;

  const filteredItems = menuItems.filter((item) => item.isAvailable);

  return (
    <div className="pb-32 pt-2 px-4 max-w-md mx-auto space-y-4">
      
      {/* Student & Budget Header Info Strip */}
      <div className="p-3.5 rounded-2xl bg-sky-50/95 border border-purple-300 flex items-center justify-between shadow-md">
        <div className="flex items-center space-x-2.5">
          <div className="w-8 h-8 rounded-full bg-purple-800 flex items-center justify-center font-black text-white text-xs">
            {selectedStudent.firstName[0]}
          </div>
          <div>
            <div className="text-xs font-bold text-purple-950">
              {selectedStudent.firstName} ({selectedStudent.parentName})
            </div>
            <div className="text-[10px] text-purple-800 font-semibold">
              {peopleCount} {peopleCount === 1 ? 'Person' : 'People'} • Max Budget ₹{allowedBudget}
            </div>
          </div>
        </div>

        {/* Status Badge */}
        <div
          className={`px-3 py-1 rounded-full text-[11px] font-bold border flex items-center space-x-1 ${
            isExceeded
              ? 'bg-red-100 text-red-700 border-red-300'
              : 'bg-emerald-100 text-emerald-800 border-emerald-300'
          }`}
        >
          {isExceeded ? (
            <>
              <AlertTriangle className="w-3 h-3 text-red-600" />
              <span>Over Budget</span>
            </>
          ) : (
            <>
              <ShieldCheck className="w-3 h-3 text-emerald-700" />
              <span>₹{allowedBudget - currentTotal} Left</span>
            </>
          )}
        </div>
      </div>

      {/* Food Cards List */}
      <div className="space-y-3.5 pt-1">
        {filteredItems.length > 0 ? (
          filteredItems.map((food) => {
            const inCartItem = cart.find((c) => c.food.id === food.id);
            const inCartQty = inCartItem ? inCartItem.quantity : 0;

            return (
              <div
                key={food.id}
                onClick={() => setSelectedFoodForModal(food)}
                className="p-3.5 rounded-2xl bg-sky-50/90 border border-purple-300 hover:border-purple-400 transition-all duration-200 shadow-md cursor-pointer flex space-x-3.5 group relative overflow-hidden active:scale-[0.99]"
              >
                {/* Food Image */}
                <div className="relative w-24 h-24 sm:w-28 sm:h-28 rounded-xl overflow-hidden flex-shrink-0 bg-sky-200">
                  <img
                    src={food.image}
                    alt={food.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute top-1.5 left-1.5 w-3 h-3 rounded-full bg-emerald-500 border border-white shadow-sm" />

                  {inCartQty > 0 && (
                    <div className="absolute bottom-1 right-1 px-2 py-0.5 rounded-md bg-purple-800 text-white font-black text-xs shadow-md">
                      {inCartQty} in cart
                    </div>
                  )}
                </div>

                {/* Details */}
                <div className="flex-1 flex flex-col justify-between">
                  <div>
                    <div className="flex items-start justify-between">
                      <h3 className="text-base font-black text-purple-950 group-hover:text-purple-800 transition-colors">
                        {food.name}
                      </h3>
                    </div>
                    <p className="text-xs text-purple-900 line-clamp-2 mt-1">
                      {food.description}
                    </p>
                  </div>

                  <div className="flex items-center justify-between pt-2">
                    <span className="text-lg font-black text-purple-950">
                      ₹{food.price}
                    </span>

                    <span className="text-xs font-bold text-purple-900 group-hover:text-purple-950 transition-colors flex items-center space-x-1 bg-purple-100 px-2.5 py-1 rounded-lg border border-purple-300">
                      <span>Tap to View</span>
                      <ChevronRight className="w-3.5 h-3.5" />
                    </span>
                  </div>
                </div>
              </div>
            );
          })
        ) : (
          <div className="py-12 text-center text-purple-800 font-medium text-sm">
            No dishes found matching your search.
          </div>
        )}
      </div>

      {/* Food Detail Modal Popup */}
      <FoodDetailModal
        food={selectedFoodForModal}
        onClose={() => setSelectedFoodForModal(null)}
        onAddToCart={onAddToCart}
        currentInCartQty={
          selectedFoodForModal
            ? cart.find((c) => c.food.id === selectedFoodForModal.id)?.quantity || 0
            : 0
        }
      />

      {/* Fixed Floating Bottom Cart Bar */}
      {totalCartCount > 0 && (
        <div className="fixed bottom-4 left-0 right-0 z-40 px-4 max-w-md mx-auto">
          <div
            onClick={onOpenCart}
            className={`p-3.5 rounded-2xl shadow-2xl flex items-center justify-between cursor-pointer backdrop-blur-xl border transition-all duration-300 ${
              isExceeded
                ? 'bg-gradient-to-r from-red-900/95 via-purple-950/95 to-red-950/95 border-red-500/60 ring-2 ring-red-500/40'
                : 'bg-gradient-to-r from-purple-900/95 via-indigo-900/95 to-purple-950/95 border-amber-500/50 ring-2 ring-purple-400/40'
            }`}
          >
            <div className="flex items-center space-x-3">
              <div className="relative p-2.5 rounded-xl bg-amber-500 text-purple-950 font-black shadow-md">
                <ShoppingBag className="w-5 h-5" />
                <span className="absolute -top-1.5 -right-1.5 w-5 h-5 rounded-full bg-white text-purple-950 text-xs font-extrabold flex items-center justify-center shadow">
                  {totalCartCount}
                </span>
              </div>

              <div>
                <div className="text-xs font-semibold text-purple-200">
                  {isExceeded ? '⚠️ Over Budget' : 'Current Total'}
                </div>
                <div className="text-lg font-black text-amber-300">
                  ₹{currentTotal}{' '}
                  <span className="text-xs font-normal text-purple-200">
                    / ₹{allowedBudget}
                  </span>
                </div>
              </div>
            </div>

            <div className="flex items-center space-x-1 text-white font-extrabold text-sm uppercase bg-amber-500/20 px-3 py-2 rounded-xl border border-amber-500/40">
              <span>View Cart</span>
              <ChevronRight className="w-4 h-4" />
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
