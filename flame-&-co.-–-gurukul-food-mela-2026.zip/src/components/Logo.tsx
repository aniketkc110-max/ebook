import React from 'react';
import familyFiestaLogo from '../assets/images/family_fiesta_logo_1787459637243.jpg';

interface LogoProps {
  size?: 'sm' | 'md' | 'lg' | 'xl';
  className?: string;
  showText?: boolean;
}

export const Logo: React.FC<LogoProps> = ({ size = 'md', className = '', showText = false }) => {
  const sizeClasses = {
    sm: 'w-9 h-9 rounded-full',
    md: 'w-11 h-11 rounded-full',
    lg: 'w-20 h-20 rounded-full',
    xl: 'w-32 h-32 rounded-full',
  };

  return (
    <div className={`flex items-center space-x-2 ${className}`}>
      <div className={`relative flex items-center justify-center overflow-hidden bg-white border-2 border-purple-300 shadow-md p-0.5 ${sizeClasses[size]}`}>
        <img
          src={familyFiestaLogo}
          alt="Family Fiesta 2026 Logo"
          referrerPolicy="no-referrer"
          className="w-full h-full object-contain rounded-full"
        />
      </div>
      {showText && (
        <div>
          <h1 className="text-xl font-black tracking-tight text-purple-950">
            Family Fiesta
          </h1>
        </div>
      )}
    </div>
  );
};
