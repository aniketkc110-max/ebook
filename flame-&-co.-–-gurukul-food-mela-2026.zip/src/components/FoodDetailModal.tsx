import React, { useState } from 'react';
import { FoodItem } from '../types';
import { X, Plus, Minus, Sparkles, ShoppingBag, Flame } from 'lucide-react';

interface FoodDetailModalProps {
  food: FoodItem | null;
  onClose: () => void;
  onAddToCart: (food: FoodItem, quantity: number) => void;
  currentInCartQty?: number;
}

export const FoodDetailModal: React.FC<FoodDetailModalProps> = ({
  food,
  onClose,
  onAddToCart,
  currentInCartQty = 0,
}) => {
  const [quantity, setQuantity] = useState<number>(currentInCartQty > 0 ? currentInCartQty : 1);

  if (!food) return null;

  const itemTotal = food.price * quantity;

  const handleAdd = () => {
    onAddToCart(food, quantity);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      
      <div className="w-full max-w-md bg-sky-50 border border-purple-300 rounded-t-3xl sm:rounded-3xl shadow-2xl overflow-hidden relative max-h-[90vh] flex flex-col animate-in slide-in-from-bottom duration-300">
        
        {/* Header Image with close button */}
        <div className="relative h-56 sm:h-64 w-full bg-sky-200 flex-shrink-0">
          <img
            src={food.image}
            alt={food.name}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-sky-50 via-transparent to-black/40" />

          {/* Close button */}
          <button
            type="button"
            onClick={onClose}
            className="absolute top-4 right-4 p-2.5 rounded-full bg-purple-950/80 text-white hover:bg-purple-900 transition-colors border border-purple-300/40 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>

          {/* Veg dot badge */}
          <div className="absolute top-4 left-4 px-2.5 py-1 rounded-full bg-white/90 border border-emerald-500/60 flex items-center space-x-1.5 backdrop-blur-md">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-600 animate-pulse" />
            <span className="text-xs font-bold text-emerald-800">100% Pure Veg</span>
          </div>

          {/* Special badge */}
          {food.isChefSpecial && (
            <div className="absolute bottom-4 left-4 px-3 py-1 rounded-full bg-gradient-to-r from-purple-700 to-purple-900 text-white font-bold text-xs shadow-lg flex items-center space-x-1">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Chef Special</span>
            </div>
          )}
        </div>

        {/* Content Body */}
        <div className="p-5 sm:p-6 space-y-4 overflow-y-auto custom-scrollbar flex-1">
          
          <div>
            <div className="flex items-start justify-between">
              <h2 className="text-2xl font-black text-purple-950 leading-tight">
                {food.name}
              </h2>
              <span className="text-2xl font-black text-purple-950 ml-3 flex-shrink-0">
                ₹{food.price}
              </span>
            </div>
            <p className="text-xs text-purple-800 font-bold uppercase tracking-wider mt-1">
              {food.category}
            </p>
          </div>

          <p className="text-sm text-purple-900 leading-relaxed bg-sky-100 p-3.5 rounded-xl border border-purple-200 font-medium">
            {food.description}
          </p>

          {/* Quantity Selector */}
          <div className="pt-2">
            <label className="block text-xs font-bold text-purple-950 uppercase tracking-wider mb-2">
              Select Quantity
            </label>
            <div className="flex items-center justify-between p-3 rounded-2xl bg-sky-100 border border-purple-300">
              <span className="text-sm font-bold text-purple-950">Portion Count:</span>

              <div className="flex items-center space-x-4">
                <button
                  type="button"
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  className="w-10 h-10 rounded-xl bg-purple-200 border border-purple-300 text-purple-950 flex items-center justify-center font-bold text-lg hover:bg-purple-300 transition-colors active:scale-95 cursor-pointer"
                >
                  <Minus className="w-4 h-4" />
                </button>

                <span className="text-xl font-black text-purple-950 w-6 text-center">
                  {quantity}
                </span>

                <button
                  type="button"
                  onClick={() => setQuantity(quantity + 1)}
                  className="w-10 h-10 rounded-xl bg-purple-800 border border-purple-600 text-white flex items-center justify-center font-bold text-lg hover:bg-purple-900 transition-all active:scale-95 shadow-md cursor-pointer"
                >
                  <Plus className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>

        </div>

        {/* Footer Action */}
        <div className="p-4 sm:p-5 bg-sky-100 border-t border-purple-300 flex-shrink-0">
          <button
            type="button"
            onClick={handleAdd}
            className="w-full py-4 px-6 rounded-2xl bg-gradient-to-r from-purple-700 via-purple-800 to-purple-900 text-white font-black text-base uppercase tracking-wider shadow-xl hover:brightness-110 active:scale-[0.98] transition-all flex items-center justify-between ring-2 ring-purple-500/40 cursor-pointer"
          >
            <div className="flex items-center space-x-2">
              <ShoppingBag className="w-5 h-5" />
              <span>Add to Cart</span>
            </div>
            <span className="text-purple-100 font-extrabold text-lg">
              ₹{itemTotal}
            </span>
          </button>
        </div>

      </div>

    </div>
  );
};
