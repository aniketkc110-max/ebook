import React from 'react';
import { ShieldCheck } from 'lucide-react';
import { Logo } from './Logo';

interface HeaderProps {
  currentView: 'home' | 'menu' | 'cart' | 'confirmation' | 'submitted' | 'admin';
  onNavigateHome?: () => void;
  onOpenAdmin: () => void;
  selectedStudentName?: string;
  cartCount?: number;
  onOpenCart?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentView,
  onNavigateHome,
  onOpenAdmin,
  selectedStudentName,
  cartCount = 0,
  onOpenCart,
}) => {
  return (
    <header className="sticky top-0 z-40 bg-sky-200/90 backdrop-blur-xl border-b border-purple-300/60 px-4 py-3 shadow-md">
      <div className="max-w-md mx-auto flex items-center justify-between">
        
        {/* Left Side: Logo & Name */}
        <div className="flex items-center cursor-pointer" onClick={onNavigateHome}>
          <Logo size="md" showText={true} />
        </div>

        {/* Right Side Controls */}
        <div className="flex items-center space-x-2">
          {/* Admin Access Button */}
          <button
            type="button"
            onClick={onOpenAdmin}
            title="Admin Portal"
            className="p-2 rounded-xl bg-purple-100 border border-purple-300 text-purple-900 hover:text-purple-950 hover:bg-purple-200 transition-all active:scale-95 flex items-center space-x-1 cursor-pointer"
          >
            <ShieldCheck className="w-4 h-4 text-purple-800" />
            <span className="text-xs font-bold hidden sm:inline">Admin</span>
          </button>
        </div>

      </div>
    </header>
  );
};
