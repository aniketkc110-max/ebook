import React from 'react';
import { Order } from '../types';
import { Lock, ShieldAlert, CheckCircle2, Flame, Clock, ChefHat, Sparkles } from 'lucide-react';
import { OrderConfirmation } from './OrderConfirmation';

interface AlreadySubmittedViewProps {
  order: Order;
  onRefreshOrder?: (updated: Order) => void;
}

export const AlreadySubmittedView: React.FC<AlreadySubmittedViewProps> = ({ order, onRefreshOrder }) => {
  return (
    <div className="min-h-[calc(100vh-65px)] p-4 sm:p-6 max-w-md mx-auto space-y-5">
      
      {/* Alert Header Box */}
      <div className="p-6 rounded-3xl bg-sky-50 border border-purple-300 shadow-xl text-center space-y-3 relative overflow-hidden">
        <div className="w-16 h-16 rounded-2xl bg-purple-800 flex items-center justify-center mx-auto shadow-md border border-purple-600">
          <Lock className="w-8 h-8 text-white" />
        </div>

        <div>
          <h2 className="text-2xl font-black text-purple-950">
            Order Already Submitted
          </h2>
          <p className="text-sm font-bold text-purple-800 mt-1">
            This device has already placed an order.
          </p>
        </div>

        <p className="text-xs text-purple-900 font-medium pt-2 border-t border-purple-200 max-w-xs mx-auto">
          As per Gurukul Food Mela 2026 rules, each student/device is limited to one single order. Your order summary and live kitchen status are shown below.
        </p>
      </div>

      {/* Embedded Order Tracker & Summary */}
      <OrderConfirmation order={order} onRefreshOrder={onRefreshOrder} />

    </div>
  );
};
