import React from 'react';
import { Order } from '../../types';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  LabelList,
} from 'recharts';

interface AnalyticsChartsProps {
  orders: Order[];
}

export const AnalyticsCharts: React.FC<AnalyticsChartsProps> = ({ orders }) => {
  // Aggregate Most Popular Food Items
  const foodCounts: Record<string, number> = {};
  orders.forEach((o) => {
    o.items.forEach((item) => {
      foodCounts[item.name] = (foodCounts[item.name] || 0) + item.quantity;
    });
  });

  const popularFoodData = Object.entries(foodCounts)
    .map(([name, count]) => ({
      fullName: name,
      name: name.length > 18 ? name.substring(0, 18) + '...' : name,
      count,
    }))
    .sort((a, b) => b.count - a.count)
    .slice(0, 6);

  // Aggregate Order Statuses
  const statusCounts: Record<string, number> = {
    Pending: 0,
    Preparing: 0,
    Ready: 0,
    Completed: 0,
  };

  orders.forEach((o) => {
    if (statusCounts[o.status] !== undefined) {
      statusCounts[o.status]++;
    }
  });

  const statusData = Object.entries(statusCounts).map(([status, count]) => ({
    name: status,
    value: count,
  }));

  const COLORS = ['#F59E0B', '#8B5CF6', '#10B981', '#3B82F6'];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
      
      {/* Popular Food Chart */}
      <div className="p-5 rounded-2xl bg-sky-100 border border-purple-300 shadow-md space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-black text-purple-950 uppercase tracking-wider">
            🔥 Most Ordered Dishes
          </h3>
          <span className="text-[10px] font-extrabold text-purple-950 bg-purple-200 px-2 py-0.5 rounded-md border border-purple-300">
            Live Quantity
          </span>
        </div>

        {popularFoodData.length > 0 ? (
          <>
            <div className="h-56 w-full pt-2">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={popularFoodData} margin={{ top: 22, right: 10, left: -20, bottom: 25 }}>
                  <XAxis dataKey="name" stroke="#581C87" fontSize={11} angle={-25} textAnchor="end" interval={0} fontWeight="bold" />
                  <YAxis stroke="#581C87" fontSize={11} allowDecimals={false} domain={[0, 'dataMax + 2']} fontWeight="bold" />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#FFFFFF',
                      borderColor: '#D8B4FE',
                      borderRadius: '12px',
                      color: '#3B0764',
                      boxShadow: '0 4px 12px rgba(0,0,0,0.1)',
                      fontWeight: 'bold',
                    }}
                    formatter={(value: any) => [`${value} Qty`, 'Quantity Ordered']}
                  />
                  <Bar dataKey="count" fill="#6B21A8" radius={[6, 6, 0, 0]}>
                    <LabelList dataKey="count" position="top" fill="#581C87" fontSize={12} fontWeight="bold" />
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>

            {/* Exact Digit List Breakdown */}
            <div className="pt-3 border-t border-purple-200 space-y-2">
              <div className="text-[11px] font-extrabold text-purple-900 uppercase tracking-wider">
                Exact Order Count Breakdown
              </div>
              <div className="grid grid-cols-2 gap-2 text-xs">
                {popularFoodData.map((item, idx) => (
                  <div
                    key={item.fullName}
                    className="flex items-center justify-between px-2.5 py-1.5 rounded-xl bg-white border border-purple-200 shadow-sm"
                  >
                    <span className="text-purple-950 font-bold truncate pr-1" title={item.fullName}>
                      <span className="text-purple-700 font-extrabold mr-1">#{idx + 1}</span>
                      {item.fullName}
                    </span>
                    <span className="font-black text-purple-950 px-2 py-0.5 rounded-lg bg-purple-100 border border-purple-300 text-xs shrink-0">
                      {item.count}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </>
        ) : (
          <div className="h-64 flex items-center justify-center text-purple-800 text-xs font-medium">
            No orders placed yet to calculate item popularity.
          </div>
        )}
      </div>

      {/* Order Status Distribution Chart */}
      <div className="p-5 rounded-2xl bg-sky-100 border border-purple-300 shadow-md space-y-3">
        <h3 className="text-sm font-black text-purple-950 uppercase tracking-wider">
          📊 Order Pipeline Status
        </h3>
        {orders.length > 0 ? (
          <div className="h-64 w-full flex items-center justify-center">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={statusData}
                  cx="50%"
                  cy="50%"
                  innerRadius={50}
                  outerRadius={80}
                  paddingAngle={5}
                  dataKey="value"
                  label={({ name, value }) => (value > 0 ? `${name}: ${value}` : '')}
                >
                  {statusData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#FFFFFF',
                    borderColor: '#D8B4FE',
                    borderRadius: '12px',
                    color: '#3B0764',
                    boxShadow: '0 4px 12px rgba(0,0,0,0.1)',
                    fontWeight: 'bold',
                  }}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>
        ) : (
          <div className="h-64 flex items-center justify-center text-purple-800 text-xs font-medium">
            No order pipeline data yet.
          </div>
        )}
      </div>

    </div>
  );
};

