import React, { useState } from 'react';
import { Order, Student, FoodItem, OrderStatus } from '../../types';
import { Logo } from '../Logo';
import {
  LayoutDashboard,
  ShoppingBag,
  Users,
  UtensilsCrossed,
  RotateCcw,
  IndianRupee,
  TrendingUp,
  Award,
  ArrowLeft,
  Trash2,
  Lock,
  LogOut,
} from 'lucide-react';
import { AnalyticsCharts } from './AnalyticsCharts';
import { OrderTable } from './OrderTable';
import { StudentManager } from './StudentManager';
import { FoodManager } from './FoodManager';

interface AdminDashboardProps {
  orders: Order[];
  students: Student[];
  menuItems: FoodItem[];
  onUpdateOrderStatus: (orderNumber: string, status: OrderStatus) => void;
  onDeleteOrder: (orderNumber: string) => void;
  onDeleteCompletedOrders?: () => void;
  onSaveMenuItems: (items: FoodItem[]) => void;
  onResetDeviceLock: () => void;
  onClearAllOrders: () => void;
  onExitAdmin: () => void;
  onLogoutAdmin: () => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({
  orders,
  students,
  menuItems,
  onUpdateOrderStatus,
  onDeleteOrder,
  onDeleteCompletedOrders,
  onSaveMenuItems,
  onResetDeviceLock,
  onClearAllOrders,
  onExitAdmin,
  onLogoutAdmin,
}) => {
  const [activeTab, setActiveTab] = useState<
    'overview' | 'orders' | 'students' | 'food' | 'settings'
  >('overview');

  // Key KPI Calculations
  const totalOrders = orders.length;
  const totalRevenue = orders.reduce((sum, o) => sum + o.totalAmount, 0);
  const avgOrderBill = totalOrders > 0 ? Math.round(totalRevenue / totalOrders) : 0;

  // Most Ordered Item
  const itemCounts: Record<string, number> = {};
  orders.forEach((o) => {
    o.items.forEach((it) => {
      itemCounts[it.name] = (itemCounts[it.name] || 0) + it.quantity;
    });
  });

  let mostOrderedItem = 'None Yet';
  let highestQty = 0;
  Object.entries(itemCounts).forEach(([name, qty]) => {
    if (qty > highestQty) {
      highestQty = qty;
      mostOrderedItem = name;
    }
  });

  const orderedStudentIds = new Set(orders.map((o) => o.studentId));
  const totalStudents = students.length;
  const studentsOrdered = orderedStudentIds.size;
  const studentsRemaining = totalStudents - studentsOrdered;

  return (
    <div className="min-h-screen bg-sky-50 text-purple-950 pb-20">
      
      {/* Top Admin Navigation Header */}
      <div className="sticky top-0 z-40 bg-sky-100/95 backdrop-blur-xl border-b border-purple-300 px-4 py-3">
        <div className="max-w-6xl mx-auto flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <button
              type="button"
              onClick={onExitAdmin}
              className="p-2 rounded-xl bg-purple-100 border border-purple-300 text-purple-950 hover:bg-purple-200 cursor-pointer"
              title="Exit Admin"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <div className="flex items-center space-x-2">
              <Logo size="sm" />
              <div>
                <h1 className="text-xl font-black text-purple-950">Family Fiesta Admin</h1>
                <p className="text-[10px] text-purple-800 font-bold uppercase tracking-wider">
                  Admin Portal
                </p>
              </div>
            </div>
          </div>

          <div className="flex items-center space-x-2 text-xs">
            <span className="px-3 py-1 rounded-full bg-purple-200 text-purple-950 border border-purple-300 font-bold hidden sm:inline">
              Authenticated Admin
            </span>
            <button
              type="button"
              onClick={onLogoutAdmin}
              className="px-3.5 py-2 rounded-xl bg-purple-800 hover:bg-purple-900 text-white font-black text-xs uppercase tracking-wider flex items-center space-x-1.5 shadow-md active:scale-95 transition-all cursor-pointer border border-purple-700"
              title="Log Out of Admin Panel"
            >
              <LogOut className="w-4 h-4" />
              <span>Log Out</span>
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto p-4 sm:p-6 space-y-6">
        
        {/* Navigation Tabs Bar */}
        <div className="flex items-center space-x-2 overflow-x-auto bg-sky-100 p-2 rounded-2xl border border-purple-300 custom-scrollbar">
          {[
            { id: 'overview', label: 'Analytics & Charts', icon: <LayoutDashboard className="w-4 h-4" /> },
            { id: 'orders', label: `Orders (${totalOrders})`, icon: <ShoppingBag className="w-4 h-4" /> },
            { id: 'students', label: `Students (${studentsOrdered}/${totalStudents})`, icon: <Users className="w-4 h-4" /> },
            { id: 'food', label: `Food Items (${menuItems.length})`, icon: <UtensilsCrossed className="w-4 h-4" /> },
            { id: 'settings', label: 'System Controls', icon: <RotateCcw className="w-4 h-4" /> },
          ].map((tab) => {
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                type="button"
                onClick={() => setActiveTab(tab.id as any)}
                className={`px-4 py-2.5 rounded-xl font-bold text-xs whitespace-nowrap transition-all duration-200 flex items-center space-x-2 cursor-pointer ${
                  isActive
                    ? 'bg-purple-800 text-white shadow-md scale-105'
                    : 'text-purple-900 hover:text-purple-950 hover:bg-purple-200/60'
                }`}
              >
                {tab.icon}
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* Tab 1: Overview & KPI Grid */}
        {activeTab === 'overview' && (
          <div className="space-y-6">
            
            {/* KPI Cards Row */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
              
              <div className="p-4 rounded-2xl bg-sky-100 border border-purple-300 shadow-md space-y-1">
                <div className="flex items-center justify-between text-purple-900 font-bold text-xs">
                  <span>Total Revenue</span>
                  <IndianRupee className="w-4 h-4 text-purple-800" />
                </div>
                <div className="text-2xl font-black text-purple-950">₹{totalRevenue}</div>
                <div className="text-[10px] text-purple-800 font-medium">Cumulative sales total</div>
              </div>

              <div className="p-4 rounded-2xl bg-sky-100 border border-purple-300 shadow-md space-y-1">
                <div className="flex items-center justify-between text-purple-900 font-bold text-xs">
                  <span>Total Orders</span>
                  <ShoppingBag className="w-4 h-4 text-purple-800" />
                </div>
                <div className="text-2xl font-black text-purple-950">{totalOrders}</div>
                <div className="text-[10px] text-purple-800 font-medium">Placed by students</div>
              </div>

              <div className="p-4 rounded-2xl bg-sky-100 border border-purple-300 shadow-md space-y-1">
                <div className="flex items-center justify-between text-purple-900 font-bold text-xs">
                  <span>Average Bill</span>
                  <TrendingUp className="w-4 h-4 text-purple-800" />
                </div>
                <div className="text-2xl font-black text-purple-950">₹{avgOrderBill}</div>
                <div className="text-[10px] text-purple-800 font-medium">Per order ticket</div>
              </div>

              <div className="p-4 rounded-2xl bg-sky-100 border border-purple-300 shadow-md space-y-1">
                <div className="flex items-center justify-between text-purple-900 font-bold text-xs">
                  <span>Top Bestseller</span>
                  <Award className="w-4 h-4 text-purple-800" />
                </div>
                <div className="text-base font-extrabold text-purple-950 truncate" title={mostOrderedItem}>
                  {mostOrderedItem}
                </div>
                <div className="text-[10px] text-purple-800 font-medium">{highestQty} portions ordered</div>
              </div>

            </div>

            {/* Recharts Analytics Section */}
            <AnalyticsCharts orders={orders} />

          </div>
        )}

        {/* Tab 2: Orders Table */}
        {activeTab === 'orders' && (
          <OrderTable
            orders={orders}
            onUpdateStatus={onUpdateOrderStatus}
          />
        )}

        {/* Tab 3: Student Directory */}
        {activeTab === 'students' && (
          <StudentManager
            students={students}
            orders={orders}
          />
        )}

        {/* Tab 4: Food Management */}
        {activeTab === 'food' && (
          <FoodManager menuItems={menuItems} onSaveMenuItems={onSaveMenuItems} />
        )}

        {/* Tab 5: System Controls */}
        {activeTab === 'settings' && (
          <div className="p-6 rounded-3xl bg-sky-100 border border-purple-300 space-y-6 max-w-xl mx-auto shadow-md">
            <h3 className="text-lg font-black text-purple-950 border-b border-purple-200 pb-3">
              Mela System Controls & Testing Tools
            </h3>

            <div className="space-y-4 text-xs">
              
              {/* Reset Device Lock */}
              <div className="p-4 rounded-2xl bg-sky-50 border border-purple-300 flex items-center justify-between">
                <div>
                  <h4 className="font-extrabold text-purple-950 text-sm">Reset Current Device Lock</h4>
                  <p className="text-purple-800 font-medium">Clears the 'One Device One Order' lock on this browser session so you can test ordering again.</p>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    onResetDeviceLock();
                    alert('Device lock cleared! You can now test placing a new order.');
                  }}
                  className="px-3.5 py-2 rounded-xl bg-purple-800 hover:bg-purple-900 text-white font-bold whitespace-nowrap ml-3 cursor-pointer"
                >
                  Clear Device Lock
                </button>
              </div>

              {/* Clear All Orders */}
              <div className="p-4 rounded-2xl bg-red-100 border border-red-300 flex items-center justify-between">
                <div>
                  <h4 className="font-extrabold text-red-950 text-sm">Wipe All Orders</h4>
                  <p className="text-red-800 font-medium">Resets the entire mela database for a fresh event start.</p>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    if (confirm('Are you sure you want to delete ALL orders? This cannot be undone.')) {
                      onClearAllOrders();
                      alert('All orders deleted successfully.');
                    }
                  }}
                  className="px-3.5 py-2 rounded-xl bg-red-600 hover:bg-red-700 text-white font-bold whitespace-nowrap ml-3 cursor-pointer"
                >
                  Clear All Orders
                </button>
              </div>

            </div>
          </div>
        )}

      </div>

    </div>
  );
};
