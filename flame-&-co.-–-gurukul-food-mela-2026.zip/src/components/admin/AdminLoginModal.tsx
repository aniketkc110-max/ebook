import React, { useState } from 'react';
import { Lock, KeyRound, X, AlertCircle } from 'lucide-react';
import { Logo } from '../Logo';

interface AdminLoginModalProps {
  isOpen: boolean;
  onClose: () => void;
  onLoginSuccess: () => void;
}

export const AdminLoginModal: React.FC<AdminLoginModalProps> = ({
  isOpen,
  onClose,
  onLoginSuccess,
}) => {
  const [password, setPassword] = useState('');
  const [error, setError] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanPwd = password.trim().toLowerCase();
    if (cleanPwd === 'jusso2026-27' || cleanPwd === 'familyfiesta2026-27' || cleanPwd === 'familyfiesta' || cleanPwd === 'admin') {
      setError(false);
      setPassword('');
      onLoginSuccess();
    } else {
      setError(true);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      
      <div className="w-full max-w-sm bg-sky-50 border border-purple-300 rounded-3xl p-6 shadow-2xl relative space-y-5 animate-in zoom-in-95 duration-200">
        
        <button
          type="button"
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-full bg-purple-100 border border-purple-300 text-purple-950 hover:bg-purple-200 cursor-pointer"
        >
          <X className="w-4 h-4" />
        </button>

        <div className="text-center space-y-2">
          <div className="flex justify-center mx-auto">
            <Logo size="lg" />
          </div>
          <h2 className="text-xl font-black text-purple-950">Admin Dashboard</h2>
          <p className="text-xs text-purple-800 font-medium">
            Enter administrator password to access Family Fiesta live management portal.
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-bold text-purple-950 uppercase tracking-wider mb-2">
              Password
            </label>
            <div className="relative">
              <KeyRound className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-purple-600" />
              <input
                type="password"
                value={password}
                onChange={(e) => {
                  setPassword(e.target.value);
                  if (error) setError(false);
                }}
                placeholder="Enter admin password..."
                className="w-full pl-10 pr-4 py-3 bg-white border border-purple-300 rounded-xl text-purple-950 placeholder-purple-400 text-sm focus:outline-none focus:border-purple-600"
                autoFocus
              />
            </div>
          </div>

          {error && (
            <div className="p-3 rounded-xl bg-red-100 border border-red-300 text-red-950 text-xs flex items-center space-x-2 font-bold">
              <AlertCircle className="w-4 h-4 text-red-600 flex-shrink-0" />
              <span>Incorrect password. Please try again.</span>
            </div>
          )}

          <button
            type="submit"
            className="w-full py-3.5 px-4 rounded-xl bg-purple-800 hover:bg-purple-900 text-white font-bold text-sm uppercase tracking-wider shadow-md active:scale-98 transition-all cursor-pointer"
          >
            Access Admin Portal
          </button>
        </form>

      </div>

    </div>
  );
};
