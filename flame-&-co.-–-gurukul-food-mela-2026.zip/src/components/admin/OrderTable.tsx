import React, { useState } from 'react';
import { Order, OrderStatus } from '../../types';
import { generateAndDownloadPDFReceipt } from '../../utils/pdfGenerator';
import {
  Search,
  Filter,
  Eye,
  X,
  Clock,
  CheckCircle2,
  ChefHat,
  Sparkles,
  Download,
  FileSpreadsheet,
  Users,
  IndianRupee,
  ShoppingBag,
  Copy,
  Check,
  ExternalLink,
  Printer,
  FileText,
} from 'lucide-react';

interface OrderTableProps {
  orders: Order[];
  onUpdateStatus: (orderNumber: string, status: OrderStatus) => void;
}

export const OrderTable: React.FC<OrderTableProps> = ({
  orders,
  onUpdateStatus,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('All');
  const [selectedOrderForReceipt, setSelectedOrderForReceipt] = useState<Order | null>(null);
  const [copied, setCopied] = useState(false);

  const filteredOrders = orders.filter((o) => {
    const query = searchQuery.toLowerCase().trim();
    const matchesQuery =
      o.orderNumber.toLowerCase().includes(query) ||
      o.studentName.toLowerCase().includes(query) ||
      o.parentName.toLowerCase().includes(query) ||
      o.fullName.toLowerCase().includes(query) ||
      o.studentId.toLowerCase().includes(query);

    const matchesStatus = statusFilter === 'All' || o.status === statusFilter;

    return matchesQuery && matchesStatus;
  });

  // Calculate sheet totals
  const sheetTotalRevenue = filteredOrders.reduce((sum, o) => sum + o.totalAmount, 0);
  const sheetTotalPeople = filteredOrders.reduce((sum, o) => sum + o.peopleCount, 0);
  const pendingCount = filteredOrders.filter((o) => o.status === 'Pending').length;
  const readyCount = filteredOrders.filter((o) => o.status === 'Ready' || o.status === 'Completed').length;

  // Download single receipt as text file
  const handleDownloadSingleReceipt = (o: Order) => {
    const cleanStudentName = o.studentName.replace(/\s*\(.*\)/, '').trim();
    const receiptText = `=========================================
  FAMILY FIESTA - RECEIPT
=========================================
Order Token  : #${o.orderNumber}
Date & Time  : ${o.dateDisplay || ''} ${o.timeDisplay}
Status       : ${o.status}

---------------- STUDENT DETAILS ----------------
Student Name : ${cleanStudentName}
Parent Name  : ${o.parentName}
Full Name    : ${o.fullName}
Student ID   : ${o.studentId}
Group Size   : ${o.peopleCount} Person(s)
Budget Limit : ₹${o.allowedBudget}

---------------- ORDERED ITEMS ------------------
${o.items.map((i) => `${i.quantity}x ${i.name.padEnd(24)} ₹${i.total}`).join('\n')}

-------------------------------------------------
TOTAL AMOUNT : ₹${o.totalAmount}
BUDGET CHECK : ${o.totalAmount <= o.allowedBudget ? 'PASSED (Within Budget)' : 'EXCEEDED BUDGET'}
=========================================
Thank you for ordering from Family Fiesta!
`;

    const blob = new Blob([receiptText], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `Family_Fiesta_Receipt_Order_${o.orderNumber}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  // 1-Click Copy All Orders formatted directly for Google Sheets (Tab-Separated TSV)
  const handleCopySheetData = () => {
    if (orders.length === 0) {
      alert('No order data available to copy.');
      return;
    }

    const headers = [
      'Order Token #',
      'Student First Name',
      'Parent Name',
      'Full Name',
      'Student ID',
      'Group People Count',
      'Allowed Budget (INR)',
      'Order Total (INR)',
      'Budget Status',
      'Ordered Food Items & Qty',
      'Order Date & Time',
      'Status',
      'Device ID',
    ];

    const rows = orders.map((o) => {
      const itemsList = o.items.map((i) => `${i.quantity}x ${i.name} (₹${i.total})`).join(' | ');
      const budgetStatus = o.totalAmount <= o.allowedBudget ? 'Within Budget' : 'Exceeded';
      const cleanStudentFirst = o.studentName.replace(/\s*\(.*\)/, '').trim();

      return [
        o.orderNumber,
        cleanStudentFirst,
        o.parentName,
        o.fullName,
        o.studentId,
        o.peopleCount,
        o.allowedBudget,
        o.totalAmount,
        budgetStatus,
        itemsList,
        `${o.dateDisplay} ${o.timeDisplay}`,
        o.status,
        o.deviceId,
      ].join('\t');
    });

    const tsvContent = [headers.join('\t'), ...rows].join('\n');

    navigator.clipboard.writeText(tsvContent).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 3500);
    }).catch((err) => {
      console.error('Failed to copy sheet data: ', err);
    });
  };

  // Export CSV Sheet function for event organizers (with UTF-8 BOM)
  const handleExportCSV = () => {
    if (orders.length === 0) {
      alert('No order data available to export.');
      return;
    }

    const headers = [
      'Order Token #',
      'Student First Name',
      'Parent Name',
      'Full Name',
      'Student ID',
      'Group People Count',
      'Allowed Budget (INR)',
      'Order Total (INR)',
      'Budget Status',
      'Ordered Food Items & Qty',
      'Order Date & Time',
      'Status',
      'Device ID',
    ];

    const rows = orders.map((o) => {
      const itemsList = o.items.map((i) => `${i.quantity}x ${i.name} (₹${i.total})`).join(' | ');
      const budgetStatus = o.totalAmount <= o.allowedBudget ? 'Within Budget' : 'Exceeded';
      const cleanStudentFirst = o.studentName.replace(/\s*\(.*\)/, '').trim();

      return [
        `"${o.orderNumber}"`,
        `"${cleanStudentFirst}"`,
        `"${o.parentName}"`,
        `"${o.fullName}"`,
        `"${o.studentId}"`,
        o.peopleCount,
        o.allowedBudget,
        o.totalAmount,
        `"${budgetStatus}"`,
        `"${itemsList.replace(/"/g, '""')}"`,
        `"${o.dateDisplay} ${o.timeDisplay}"`,
        `"${o.status}"`,
        `"${o.deviceId}"`,
      ];
    });

    const csvContent = '\uFEFF' + [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `Family_Fiesta_Gurukul_Food_Mela_All_Orders_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-4">
      
      {/* Top Banner Sheet Action & Metrics Bar */}
      <div className="bg-sky-100 border border-purple-300 p-4 rounded-2xl shadow-md space-y-4">
        
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3 border-b border-purple-200 pb-3">
          <div>
            <div className="flex items-center space-x-2">
              <FileSpreadsheet className="w-5 h-5 text-purple-800" />
              <h2 className="text-base font-black text-purple-950">All Master Orders Sheet</h2>
            </div>
            <p className="text-xs text-purple-800 mt-0.5 font-medium">
              Live comprehensive registry of all {orders.length} student food orders for Family Fiesta 2026.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {/* 1-Click Copy Data for Google Sheets */}
            <button
              type="button"
              onClick={handleCopySheetData}
              className="px-3.5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-black uppercase tracking-wider shadow-md active:scale-95 flex items-center space-x-1.5 cursor-pointer border border-emerald-500 transition-all"
              title="Copy all order data to paste directly into Google Sheets (Ctrl+V)"
            >
              {copied ? <Check className="w-4 h-4 text-emerald-200" /> : <Copy className="w-4 h-4" />}
              <span>{copied ? 'Copied All Data!' : 'Copy Data for Google Sheets'}</span>
            </button>

            {/* Open blank Google Sheet */}
            <a
              href="https://sheets.new"
              target="_blank"
              rel="noopener noreferrer"
              className="px-3 py-2.5 rounded-xl bg-purple-100 hover:bg-purple-200 border border-purple-300 text-purple-950 text-xs font-bold uppercase tracking-wider flex items-center space-x-1.5 active:scale-95 transition-all"
              title="Open a blank Google Sheet in new tab"
            >
              <ExternalLink className="w-3.5 h-3.5 text-purple-800" />
              <span>Open Google Sheets</span>
            </a>

            {/* Download CSV Sheet */}
            <button
              type="button"
              onClick={handleExportCSV}
              className="px-3.5 py-2.5 rounded-xl bg-purple-800 hover:bg-purple-900 text-white text-xs font-black uppercase tracking-wider shadow-md active:scale-95 flex items-center space-x-1.5 cursor-pointer border border-purple-700"
              title="Download 1-click CSV file containing all orders"
            >
              <Download className="w-4 h-4" />
              <span>Download CSV File</span>
            </button>
          </div>
        </div>

        {copied && (
          <div className="p-3 rounded-xl bg-emerald-100 border border-emerald-300 text-emerald-950 text-xs font-semibold flex items-center space-x-2">
            <Check className="w-4 h-4 text-emerald-700 shrink-0" />
            <span>
              <strong>All {orders.length} orders copied to clipboard!</strong> Open Google Sheets, click on cell <strong>A1</strong>, and press <strong>Ctrl + V</strong> (Paste) to fill all columns automatically.
            </span>
          </div>
        )}

        {/* Quick Sheet Summary Statistics */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
          <div className="p-2.5 rounded-xl bg-white border border-purple-200 flex justify-between items-center shadow-sm">
            <div>
              <div className="text-[10px] text-purple-800 uppercase font-semibold">Filtered Orders</div>
              <div className="text-lg font-black text-purple-950">{filteredOrders.length}</div>
            </div>
            <ShoppingBag className="w-4 h-4 text-purple-700" />
          </div>

          <div className="p-2.5 rounded-xl bg-white border border-purple-200 flex justify-between items-center shadow-sm">
            <div>
              <div className="text-[10px] text-purple-800 uppercase font-semibold">Total Revenue</div>
              <div className="text-lg font-black text-purple-950">₹{sheetTotalRevenue}</div>
            </div>
            <IndianRupee className="w-4 h-4 text-purple-700" />
          </div>

          <div className="p-2.5 rounded-xl bg-white border border-purple-200 flex justify-between items-center shadow-sm">
            <div>
              <div className="text-[10px] text-purple-800 uppercase font-semibold">Total People Fed</div>
              <div className="text-lg font-black text-purple-950">{sheetTotalPeople}</div>
            </div>
            <Users className="w-4 h-4 text-purple-700" />
          </div>

          <div className="p-2.5 rounded-xl bg-white border border-purple-200 flex justify-between items-center shadow-sm">
            <div>
              <div className="text-[10px] text-purple-800 uppercase font-semibold">Pending / Ready</div>
              <div className="text-lg font-black text-purple-950">{pendingCount} / {readyCount}</div>
            </div>
            <Clock className="w-4 h-4 text-purple-700" />
          </div>
        </div>

      </div>

      {/* Search & Status Filter Controls */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 bg-sky-100 p-3.5 rounded-2xl border border-purple-300">
        
        {/* Search */}
        <div className="relative w-full sm:w-80">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-purple-600" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search by student, parent, ID, token #..."
            className="w-full pl-9 pr-3 py-2 bg-white border border-purple-300 rounded-xl text-purple-950 placeholder-purple-400 text-xs focus:outline-none focus:border-purple-600"
          />
        </div>

        {/* Status Filter Tabs */}
        <div className="flex items-center space-x-1 overflow-x-auto w-full sm:w-auto custom-scrollbar">
          {['All', 'Pending', 'Preparing', 'Ready', 'Completed'].map((st) => (
            <button
              key={st}
              type="button"
              onClick={() => setStatusFilter(st)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all cursor-pointer ${
                statusFilter === st
                  ? 'bg-purple-800 text-white shadow-md'
                  : 'bg-purple-100 text-purple-950 hover:bg-purple-200'
              }`}
            >
              {st}
            </button>
          ))}
        </div>

      </div>

      {/* Full Detailed Spreadsheet Table Container */}
      <div className="bg-white border border-purple-300 rounded-2xl overflow-hidden shadow-md">
        <div className="overflow-x-auto custom-scrollbar">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-sky-100 border-b border-purple-300 text-purple-950 font-bold uppercase tracking-wider">
                <th className="p-3 whitespace-nowrap">Order #</th>
                <th className="p-3 whitespace-nowrap">Student First</th>
                <th className="p-3 whitespace-nowrap">Parent Name</th>
                <th className="p-3 whitespace-nowrap">Full Name & ID</th>
                <th className="p-3 whitespace-nowrap text-center">Group</th>
                <th className="p-3 whitespace-nowrap min-w-[200px]">Ordered Items Breakdown</th>
                <th className="p-3 whitespace-nowrap">Total ₹</th>
                <th className="p-3 whitespace-nowrap">Budget Status</th>
                <th className="p-3 whitespace-nowrap">Date / Time</th>
                <th className="p-3 whitespace-nowrap">Kitchen Status</th>
                <th className="p-3 whitespace-nowrap text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-purple-200 text-purple-950">
              {filteredOrders.length > 0 ? (
                filteredOrders.map((order) => {
                  const itemsSummary = order.items
                    .map((i) => `${i.quantity}x ${i.name} (₹${i.total})`)
                    .join(', ');

                  const isWithinBudget = order.totalAmount <= order.allowedBudget;
                  const cleanStudentFirst = order.studentName.replace(/\s*\(.*\)/, '').trim();

                  return (
                    <tr key={order.orderNumber} className="hover:bg-purple-50 transition-colors">
                      <td className="p-3 font-mono font-extrabold text-purple-950 whitespace-nowrap">
                        #{order.orderNumber}
                      </td>
                      <td className="p-3 font-extrabold text-purple-950 whitespace-nowrap">
                        {cleanStudentFirst}
                      </td>
                      <td className="p-3 text-purple-900 whitespace-nowrap font-medium">
                        {order.parentName}
                      </td>
                      <td className="p-3 text-purple-900 whitespace-nowrap">
                        <span className="font-semibold text-purple-950">{order.fullName}</span>
                        <span className="ml-1 text-[10px] text-purple-700 font-mono font-bold">({order.studentId})</span>
                      </td>
                      <td className="p-3 font-black text-center whitespace-nowrap">
                        <span className="px-2 py-0.5 rounded-md bg-purple-100 text-purple-950 border border-purple-200">
                          {order.peopleCount} p.
                        </span>
                      </td>
                      <td className="p-3 text-purple-900 max-w-xs truncate font-medium" title={itemsSummary}>
                        {itemsSummary}
                      </td>
                      <td className="p-3 font-black text-purple-950 text-sm whitespace-nowrap">
                        ₹{order.totalAmount}
                      </td>
                      <td className="p-3 whitespace-nowrap">
                        <span
                          className={`px-2 py-0.5 rounded-full text-[10px] font-extrabold ${
                            isWithinBudget
                              ? 'bg-emerald-100 border border-emerald-300 text-emerald-950'
                              : 'bg-red-100 border border-red-300 text-red-950'
                          }`}
                        >
                          {isWithinBudget ? `OK (Max ₹${order.allowedBudget})` : `Over by ₹${order.totalAmount - order.allowedBudget}`}
                        </span>
                      </td>
                      <td className="p-3 text-purple-800 text-[11px] whitespace-nowrap font-medium">
                        {order.dateDisplay || ''} {order.timeDisplay}
                      </td>
                      <td className="p-3 whitespace-nowrap">
                        <select
                          value={order.status}
                          onChange={(e) => onUpdateStatus(order.orderNumber, e.target.value as OrderStatus)}
                          className={`px-2.5 py-1.5 rounded-xl font-bold text-xs border focus:outline-none cursor-pointer ${
                            order.status === 'Pending'
                              ? 'bg-amber-100 border-amber-300 text-amber-950'
                              : order.status === 'Preparing'
                              ? 'bg-purple-100 border-purple-300 text-purple-950'
                              : order.status === 'Ready'
                              ? 'bg-emerald-100 border-emerald-300 text-emerald-950'
                              : 'bg-blue-100 border-blue-300 text-blue-950'
                          }`}
                        >
                          <option value="Pending">Pending</option>
                          <option value="Preparing">Preparing</option>
                          <option value="Ready">Ready</option>
                          <option value="Completed">Completed</option>
                        </select>
                      </td>
                      <td className="p-3 text-right whitespace-nowrap">
                        <button
                          type="button"
                          onClick={() => setSelectedOrderForReceipt(order)}
                          title="View Full Order Receipt & Details"
                          className="px-3 py-1.5 rounded-xl bg-purple-100 hover:bg-purple-200 text-purple-950 text-xs font-bold inline-flex items-center space-x-1 border border-purple-300 active:scale-95 transition-all cursor-pointer"
                        >
                          <Eye className="w-3.5 h-3.5" />
                          <span>View Details</span>
                        </button>
                      </td>
                    </tr>
                  );
                })
              ) : (
                <tr>
                  <td colSpan={11} className="p-8 text-center text-purple-800 font-medium">
                    No order records found matching your query.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Comprehensive Order Detail Sheet Modal */}
      {selectedOrderForReceipt && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-md">
          <div className="printable-receipt w-full max-w-lg bg-sky-50 border border-purple-300 rounded-3xl p-6 shadow-2xl space-y-4 relative">
            <button
              type="button"
              onClick={() => setSelectedOrderForReceipt(null)}
              className="no-print absolute top-4 right-4 p-2 rounded-full bg-purple-100 text-purple-950 hover:bg-purple-200 cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>

            <div className="border-b border-purple-200 pb-3">
              <span className="px-2.5 py-0.5 rounded-full bg-purple-200 text-purple-950 border border-purple-300 text-[10px] font-bold uppercase tracking-wider">
                Order Receipt Token
              </span>
              <h3 className="text-xl font-black text-purple-950 mt-1">Order #{selectedOrderForReceipt.orderNumber}</h3>
              <p className="text-xs text-purple-800 font-medium">
                Placed on {selectedOrderForReceipt.dateDisplay || ''} at {selectedOrderForReceipt.timeDisplay}
              </p>
            </div>

            <div className="grid grid-cols-2 gap-2 text-xs bg-white p-3 rounded-2xl border border-purple-200">
              <div>
                <span className="text-purple-800 text-[10px] block uppercase font-bold">Student First Name</span>
                <span className="font-bold text-purple-950 text-sm">{selectedOrderForReceipt.studentName.replace(/\s*\(.*\)/, '')}</span>
              </div>
              <div>
                <span className="text-purple-800 text-[10px] block uppercase font-bold">Parent Name</span>
                <span className="font-bold text-purple-950 text-sm">{selectedOrderForReceipt.parentName}</span>
              </div>
              <div className="col-span-2 pt-1 border-t border-purple-100">
                <span className="text-purple-800 text-[10px] block uppercase font-bold">Full Registered Name</span>
                <span className="font-bold text-purple-950">{selectedOrderForReceipt.fullName} ({selectedOrderForReceipt.studentId})</span>
              </div>
              <div>
                <span className="text-purple-800 text-[10px] block uppercase font-bold">Group People Count</span>
                <span className="font-bold text-purple-950">{selectedOrderForReceipt.peopleCount} People</span>
              </div>
              <div>
                <span className="text-purple-800 text-[10px] block uppercase font-bold">Allowed Budget Limit</span>
                <span className="font-bold text-purple-950">₹{selectedOrderForReceipt.allowedBudget}</span>
              </div>
              <div className="col-span-2 pt-1 border-t border-purple-100 font-mono text-[10px] text-purple-700">
                Device ID: {selectedOrderForReceipt.deviceId}
              </div>
            </div>

            <div className="border-t border-purple-200 pt-3 space-y-2">
              <div className="text-xs font-bold text-purple-950 uppercase tracking-wider">
                Line Items & Quantities
              </div>
              <div className="space-y-1.5 max-h-48 overflow-y-auto custom-scrollbar pr-1">
                {selectedOrderForReceipt.items.map((it) => (
                  <div key={it.id} className="flex justify-between text-xs py-1.5 px-3 rounded-xl bg-white border border-purple-200 text-purple-950 shadow-sm">
                    <span>
                      <strong className="text-purple-950 font-black">{it.quantity}x</strong> {it.name}
                    </span>
                    <span className="font-black text-purple-950">₹{it.total}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="border-t border-purple-200 pt-3 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <span className="text-purple-800 text-xs block font-medium">Total Bill</span>
                <span className="text-purple-950 font-black text-2xl">₹{selectedOrderForReceipt.totalAmount}</span>
              </div>
              <div className="no-print flex items-center space-x-2 flex-wrap gap-y-2">
                <button
                  type="button"
                  onClick={() => generateAndDownloadPDFReceipt(selectedOrderForReceipt)}
                  className="px-3.5 py-2 rounded-xl bg-purple-800 hover:bg-purple-900 text-white font-black text-xs uppercase tracking-wider flex items-center space-x-1.5 shadow-md active:scale-95 transition-all cursor-pointer"
                  title="Download official PDF receipt"
                >
                  <FileText className="w-3.5 h-3.5" />
                  <span>Download PDF</span>
                </button>
                <button
                  type="button"
                  onClick={() => handleDownloadSingleReceipt(selectedOrderForReceipt)}
                  className="px-3 py-2 rounded-xl bg-purple-100 hover:bg-purple-200 border border-purple-300 text-purple-950 text-xs font-bold flex items-center space-x-1 cursor-pointer"
                  title="Save order receipt as text file"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>TXT</span>
                </button>
                <button
                  type="button"
                  onClick={() => setSelectedOrderForReceipt(null)}
                  className="px-3 py-2 rounded-xl bg-purple-100 hover:bg-purple-200 border border-purple-300 text-purple-950 text-xs font-bold cursor-pointer"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
