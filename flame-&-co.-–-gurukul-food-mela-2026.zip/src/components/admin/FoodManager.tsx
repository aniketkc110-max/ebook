import React, { useState } from 'react';
import { FoodItem } from '../../types';
import { Plus, Edit2, Trash2, X, Check, Image as ImageIcon, Sparkles } from 'lucide-react';

interface FoodManagerProps {
  menuItems: FoodItem[];
  onSaveMenuItems: (items: FoodItem[]) => void;
}

export const FoodManager: React.FC<FoodManagerProps> = ({
  menuItems,
  onSaveMenuItems,
}) => {
  const [isAddingOrEditing, setIsAddingOrEditing] = useState(false);
  const [editingItem, setEditingItem] = useState<FoodItem | null>(null);

  // Form states
  const [name, setName] = useState('');
  const [category, setCategory] = useState<FoodItem['category']>('Chaat & Street Food');
  const [description, setDescription] = useState('');
  const [price, setPrice] = useState<number>(100);
  const [image, setImage] = useState('');
  const [isChefSpecial, setIsChefSpecial] = useState(false);

  const handleOpenAdd = () => {
    setEditingItem(null);
    setName('');
    setCategory('Chaat & Street Food');
    setDescription('');
    setPrice(120);
    setImage('https://images.unsplash.com/photo-1546069901-ba9599a7e63c?auto=format&fit=crop&w=600&q=80');
    setIsChefSpecial(false);
    setIsAddingOrEditing(true);
  };

  const handleOpenEdit = (item: FoodItem) => {
    setEditingItem(item);
    setName(item.name);
    setCategory(item.category);
    setDescription(item.description);
    setPrice(item.price);
    setImage(item.image);
    setIsChefSpecial(!!item.isChefSpecial);
    setIsAddingOrEditing(true);
  };

  const handleToggleAvailable = (itemId: string) => {
    const updated = menuItems.map((item) =>
      item.id === itemId ? { ...item, isAvailable: !item.isAvailable } : item
    );
    onSaveMenuItems(updated);
  };

  const handleDeleteItem = (itemId: string) => {
    if (confirm('Are you sure you want to delete this menu item?')) {
      const updated = menuItems.filter((item) => item.id !== itemId);
      onSaveMenuItems(updated);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    if (editingItem) {
      // Update
      const updated = menuItems.map((item) =>
        item.id === editingItem.id
          ? {
              ...item,
              name,
              category,
              description,
              price: Number(price),
              image,
              isChefSpecial,
            }
          : item
      );
      onSaveMenuItems(updated);
    } else {
      // Create
      const newItem: FoodItem = {
        id: 'FOOD-' + Math.floor(100 + Math.random() * 900),
        name,
        category,
        description,
        price: Number(price),
        image,
        isVeg: true,
        isChefSpecial,
        isAvailable: true,
      };
      onSaveMenuItems([...menuItems, newItem]);
    }

    setIsAddingOrEditing(false);
  };

  return (
    <div className="space-y-4">
      
      {/* Top Header & Add Button */}
      <div className="flex items-center justify-between bg-sky-100 p-4 rounded-2xl border border-purple-300 shadow-md">
        <div>
          <h3 className="text-base font-black text-purple-950">Food Menu Management</h3>
          <p className="text-xs text-purple-800 font-medium">Add, edit prices, upload photos, or disable dishes.</p>
        </div>

        <button
          type="button"
          onClick={handleOpenAdd}
          className="px-4 py-2.5 rounded-xl bg-purple-800 hover:bg-purple-900 text-white font-bold text-xs uppercase tracking-wider shadow-md flex items-center space-x-2 active:scale-95 cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>Add New Dish</span>
        </button>
      </div>

      {/* Menu Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        {menuItems.map((item) => (
          <div
            key={item.id}
            className={`p-3.5 rounded-2xl bg-white border shadow-sm transition-all flex space-x-3 relative ${
              item.isAvailable
                ? 'border-purple-300'
                : 'border-red-300 opacity-60 bg-red-50'
            }`}
          >
            <img
              src={item.image}
              alt={item.name}
              className="w-20 h-20 rounded-xl object-cover border border-purple-200 flex-shrink-0"
            />

            <div className="flex-1 flex flex-col justify-between min-w-0">
              <div>
                <div className="flex items-start justify-between">
                  <h4 className="text-sm font-black text-purple-950 truncate">{item.name}</h4>
                  <span className="text-sm font-black text-purple-950 ml-2">₹{item.price}</span>
                </div>
                <p className="text-[11px] text-purple-800 font-medium line-clamp-2 mt-0.5">{item.description}</p>
              </div>

              <div className="flex items-center justify-between pt-2 border-t border-purple-100 mt-2">
                <button
                  type="button"
                  onClick={() => handleToggleAvailable(item.id)}
                  className={`px-2.5 py-1 rounded-lg text-[10px] font-bold border transition-colors cursor-pointer ${
                    item.isAvailable
                      ? 'bg-emerald-100 text-emerald-950 border-emerald-300'
                      : 'bg-red-100 text-red-950 border-red-300'
                  }`}
                >
                  {item.isAvailable ? 'Enabled' : 'Disabled'}
                </button>

                <div className="flex items-center space-x-1">
                  <button
                    type="button"
                    onClick={() => handleOpenEdit(item)}
                    className="p-1.5 rounded-lg bg-purple-100 text-purple-950 hover:bg-purple-200 cursor-pointer"
                  >
                    <Edit2 className="w-3.5 h-3.5" />
                  </button>
                  <button
                    type="button"
                    onClick={() => handleDeleteItem(item.id)}
                    className="p-1.5 rounded-lg bg-red-100 text-red-950 hover:bg-red-200 cursor-pointer"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Add / Edit Modal */}
      {isAddingOrEditing && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-md">
          <div className="w-full max-w-md bg-sky-50 border border-purple-300 rounded-3xl p-5 shadow-2xl relative space-y-4">
            
            <button
              type="button"
              onClick={() => setIsAddingOrEditing(false)}
              className="absolute top-4 right-4 p-2 rounded-full bg-purple-100 text-purple-950 hover:bg-purple-200 cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>

            <h3 className="text-lg font-black text-purple-950">
              {editingItem ? 'Edit Dish Details' : 'Add New Dish'}
            </h3>

            <form onSubmit={handleSubmit} className="space-y-3 text-xs">
              <div>
                <label className="block text-purple-950 font-bold mb-1">Dish Name</label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full p-2.5 bg-white border border-purple-300 rounded-xl text-purple-950 placeholder-purple-400 focus:outline-none focus:border-purple-600"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-purple-950 font-bold mb-1">Category</label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value as FoodItem['category'])}
                    className="w-full p-2.5 bg-white border border-purple-300 rounded-xl text-purple-950 focus:outline-none focus:border-purple-600"
                  >
                    <option value="Chaat & Street Food">Chaat & Street Food</option>
                    <option value="Main Course">Main Course</option>
                    <option value="Beverages & Drinks">Beverages & Drinks</option>
                    <option value="Desserts">Desserts</option>
                    <option value="Healthy Special">Healthy Special</option>
                  </select>
                </div>

                <div>
                  <label className="block text-purple-950 font-bold mb-1">Price (₹)</label>
                  <input
                    type="number"
                    required
                    min={10}
                    value={price}
                    onChange={(e) => setPrice(Number(e.target.value))}
                    className="w-full p-2.5 bg-white border border-purple-300 rounded-xl text-purple-950 focus:outline-none focus:border-purple-600"
                  />
                </div>
              </div>

              <div>
                <label className="block text-purple-950 font-bold mb-1">Description</label>
                <textarea
                  rows={2}
                  required
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className="w-full p-2.5 bg-white border border-purple-300 rounded-xl text-purple-950 focus:outline-none focus:border-purple-600"
                />
              </div>

              <div>
                <label className="block text-purple-950 font-bold mb-1">Image URL</label>
                <input
                  type="url"
                  required
                  value={image}
                  onChange={(e) => setImage(e.target.value)}
                  className="w-full p-2.5 bg-white border border-purple-300 rounded-xl text-purple-950 focus:outline-none focus:border-purple-600"
                />
              </div>

              <div className="flex items-center space-x-2 pt-1">
                <input
                  type="checkbox"
                  id="chefSpec"
                  checked={isChefSpecial}
                  onChange={(e) => setIsChefSpecial(e.target.checked)}
                  className="w-4 h-4 rounded text-purple-800 focus:ring-purple-600 border-purple-300"
                />
                <label htmlFor="chefSpec" className="text-purple-950 font-bold cursor-pointer">
                  Tag as Chef's Special
                </label>
              </div>

              <button
                type="submit"
                className="w-full py-3 rounded-xl bg-purple-800 hover:bg-purple-900 text-white font-bold uppercase tracking-wider shadow-md mt-2 cursor-pointer"
              >
                {editingItem ? 'Save Changes' : 'Create Dish'}
              </button>
            </form>

          </div>
        </div>
      )}

    </div>
  );
};
