import React, { useState } from 'react';
import { Student, Order } from '../../types';
import { Search, CheckCircle2, Clock } from 'lucide-react';
import { getStudentDisplayName } from '../../data/students';

interface StudentManagerProps {
  students: Student[];
  orders: Order[];
}

export const StudentManager: React.FC<StudentManagerProps> = ({ students, orders }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [filter, setFilter] = useState<'All' | 'Ordered' | 'Remaining'>('All');

  // Map student orders
  const studentOrdersMap = new Map<string, Order>();
  orders.forEach((o) => {
    studentOrdersMap.set(o.studentId, o);
  });

  const totalStudents = students.length;
  const orderedCount = Array.from(studentOrdersMap.keys()).length;
  const remainingCount = totalStudents - orderedCount;

  const filteredStudents = students.filter((s) => {
    const hasOrdered = studentOrdersMap.has(s.id);
    if (filter === 'Ordered' && !hasOrdered) return false;
    if (filter === 'Remaining' && hasOrdered) return false;

    const query = searchQuery.toLowerCase().trim();
    return (
      s.firstName.toLowerCase().includes(query) ||
      s.parentName.toLowerCase().includes(query) ||
      s.fullName.toLowerCase().includes(query) ||
      s.id.toLowerCase().includes(query)
    );
  });

  return (
    <div className="space-y-4">
      
      {/* Stat Cards Row */}
      <div className="grid grid-cols-3 gap-3">
        <div className="p-4 rounded-2xl bg-sky-100 border border-purple-300 text-center shadow-sm">
          <div className="text-[10px] text-purple-800 uppercase tracking-wider font-extrabold">Total Students</div>
          <div className="text-2xl font-black text-purple-950 mt-1">{totalStudents}</div>
        </div>

        <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-300 text-center shadow-sm">
          <div className="text-[10px] text-emerald-800 uppercase tracking-wider font-extrabold">Ordered</div>
          <div className="text-2xl font-black text-emerald-950 mt-1">{orderedCount}</div>
        </div>

        <div className="p-4 rounded-2xl bg-amber-50 border border-amber-300 text-center shadow-sm">
          <div className="text-[10px] text-amber-800 uppercase tracking-wider font-extrabold">Remaining</div>
          <div className="text-2xl font-black text-amber-950 mt-1">{remainingCount}</div>
        </div>
      </div>

      {/* Filter & Search Bar */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 bg-sky-100 p-3.5 rounded-2xl border border-purple-300">
        <div className="relative w-full sm:w-72">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-purple-600" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search student roster..."
            className="w-full pl-9 pr-3 py-2 bg-white border border-purple-300 rounded-xl text-purple-950 placeholder-purple-400 text-xs focus:outline-none focus:border-purple-600"
          />
        </div>

        <div className="flex items-center space-x-1">
          {(['All', 'Ordered', 'Remaining'] as const).map((f) => (
            <button
              key={f}
              type="button"
              onClick={() => setFilter(f)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                filter === f
                  ? 'bg-purple-800 text-white shadow-md'
                  : 'bg-purple-100 text-purple-950 hover:bg-purple-200'
              }`}
            >
              {f}
            </button>
          ))}
        </div>
      </div>

      {/* Student List Table */}
      <div className="bg-white border border-purple-300 rounded-2xl overflow-hidden shadow-md">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="bg-sky-100 border-b border-purple-300 text-purple-950 font-bold uppercase tracking-wider">
                <th className="p-3">Student ID</th>
                <th className="p-3">Student Display Name</th>
                <th className="p-3">Parent Name</th>
                <th className="p-3">Full Internal Name</th>
                <th className="p-3">Grade</th>
                <th className="p-3">Order Status</th>
                <th className="p-3 text-right">Order Total</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-purple-200 text-purple-950">
              {filteredStudents.length > 0 ? (
                filteredStudents.map((student) => {
                  const existingOrder = studentOrdersMap.get(student.id);

                  return (
                    <tr key={student.id} className="hover:bg-purple-50 transition-colors">
                      <td className="p-3 font-mono text-purple-800 font-bold whitespace-nowrap">
                        {student.id}
                      </td>
                      <td className="p-3 font-extrabold text-purple-950 whitespace-nowrap">
                        {getStudentDisplayName(student)}
                      </td>
                      <td className="p-3 text-purple-900 whitespace-nowrap font-medium">
                        {student.parentName}
                      </td>
                      <td className="p-3 text-purple-800 whitespace-nowrap">
                        {student.fullName}
                      </td>
                      <td className="p-3 text-purple-800 whitespace-nowrap font-medium">
                        {student.grade}
                      </td>
                      <td className="p-3 whitespace-nowrap">
                        {existingOrder ? (
                          <span className="px-2.5 py-1 rounded-full bg-emerald-100 text-emerald-950 border border-emerald-300 font-bold text-[11px] inline-flex items-center space-x-1">
                            <CheckCircle2 className="w-3 h-3 text-emerald-700" />
                            <span>Ordered (#{existingOrder.orderNumber})</span>
                          </span>
                        ) : (
                          <span className="px-2.5 py-1 rounded-full bg-amber-100 text-amber-950 border border-amber-300 font-bold text-[11px] inline-flex items-center space-x-1">
                            <Clock className="w-3 h-3 text-amber-700" />
                            <span>Remaining</span>
                          </span>
                        )}
                      </td>
                      <td className="p-3 text-right font-black text-purple-950 whitespace-nowrap">
                        {existingOrder ? `₹${existingOrder.totalAmount}` : '-'}
                      </td>
                    </tr>
                  );
                })
              ) : (
                <tr>
                  <td colSpan={7} className="p-8 text-center text-purple-800 font-medium">
                    No students match your query.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
};
